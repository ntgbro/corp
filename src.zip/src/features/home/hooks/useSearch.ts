import { useState, useCallback, useMemo, useEffect } from 'react';
import { ProductData } from '../../../components/layout';
import { ChefData } from '../../../components/layout';
import { productService } from '../../../services/firebase/firestore/productService';
import { chefService } from '../../../services/firebase/firestore/chefService';

interface SearchResult {
  products: ProductData[];
  chefs: ChefData[];
  totalResults: number;
}

interface UseSearchReturn {
  query: string;
  results: SearchResult;
  loading: boolean;
  error: string | null;
  setQuery: (query: string) => void;
  search: (searchQuery: string) => Promise<void>;
  clearSearch: () => void;
  hasResults: boolean;
}

export const useSearch = (): UseSearchReturn => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult>({
    products: [],
    chefs: [],
    totalResults: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async (searchQuery: string) => {
    try {
      setLoading(true);
      setError(null);

      // Simulate API delay
      await new Promise<void>(resolve => setTimeout(resolve, 500));

      // Fetch real data from Firestore
      const [productResults, chefResults] = await Promise.all([
        productService.searchProducts(searchQuery),
        chefService.searchChefs(searchQuery)
      ]);

      setResults({
        products: productResults,
        chefs: chefResults,
        totalResults: productResults.length + chefResults.length,
      });
    } catch (err) {
      setError('Search failed. Please try again.');
      console.error('Search error:', err);

      // Fallback to mock data if Firestore fails
      console.log('Falling back to mock search data...');

      const mockProducts: ProductData[] = [
        {
          id: '1',
          name: 'Fresh Tomatoes',
          price: 40,
          rating: 4.5,
          reviewCount: 25,
          isAvailable: true,
          category: 'Fresh Produce',
        },
        {
          id: '2',
          name: 'Organic Bananas',
          price: 60,
          rating: 4.8,
          reviewCount: 42,
          isAvailable: true,
          category: 'Fresh Produce',
        },
      ];

      const mockChefs: ChefData[] = [
        {
          id: '1',
          name: 'Chef Marco',
          rating: 4.8,
          reviewCount: 156,
          specialty: 'Italian Cuisine',
          isAvailable: true,
          cuisineType: 'Italian',
        },
        {
          id: '2',
          name: 'Chef Priya',
          rating: 4.9,
          reviewCount: 203,
          specialty: 'Indian Cuisine',
          isAvailable: true,
          cuisineType: 'Indian',
        },
      ];

      const searchTerm = searchQuery.toLowerCase();
      const filteredProducts = mockProducts.filter(p =>
        p.name.toLowerCase().includes(searchTerm) ||
        p.category?.toLowerCase().includes(searchTerm)
      );
      const filteredChefs = mockChefs.filter(c =>
        c.name.toLowerCase().includes(searchTerm) ||
        c.specialty?.toLowerCase().includes(searchTerm) ||
        c.cuisineType?.toLowerCase().includes(searchTerm)
      );

      setResults({
        products: filteredProducts,
        chefs: filteredChefs,
        totalResults: filteredProducts.length + filteredChefs.length,
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const clearSearch = useCallback(() => {
    setQuery('');
    setResults({
      products: [],
      chefs: [],
      totalResults: 0,
    });
    setError(null);
  }, []);

  const hasResults = useMemo(() => {
    return results.totalResults > 0 || query.length > 0;
  }, [results.totalResults, query]);

  // Auto-search when query changes (debounced)
  useEffect(() => {
    if (query.length === 0) {
      clearSearch();
      return;
    }

    const timeoutId = setTimeout(() => {
      search(query);
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, search, clearSearch]);

  return {
    query,
    results,
    loading,
    error,
    setQuery,
    search,
    clearSearch,
    hasResults,
  };
};

export default useSearch;
