import { useState, useEffect, useCallback } from 'react';
import { ProductData } from '../../../components/layout';
import { productService, ProductCategory } from '../../../services/firebase/firestore/productService';

interface UseHomeDataReturn {
  popularProducts: ProductData[];
  categories: Array<{
    id: string;
    name: string;
    icon: string;
    productCount: number;
  }>;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

export const useHomeData = (): UseHomeDataReturn => {
  const [popularProducts, setPopularProducts] = useState<ProductData[]>([]);
  const [categories, setCategories] = useState<Array<{
    id: string;
    name: string;
    icon: string;
    productCount: number;
  }>>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadHomeData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      console.log('🔥 Loading real data from Firestore...');

      // Fetch real data from Firestore
      const [products, categoriesData] = await Promise.all([
        productService.getPopularProducts(10),
        productService.getProductCategories()
      ]);

      console.log(`✅ Loaded ${products.length} products, ${categoriesData.length} categories`);

      // Debug: Log all category names
      console.log('📂 Available categories:', categoriesData.map(cat => ({
        id: cat.id,
        name: cat.name,
        productCount: cat.productCount
      })));

      setPopularProducts(products);

      // Transform categories to match expected format
      const transformedCategories = categoriesData.map(cat => ({
        id: cat.id,
        name: cat.name,
        icon: cat.icon,
        productCount: cat.productCount
      }));

      setCategories(transformedCategories);

      // Log if no data is found (but don't seed automatically)
      if (products.length === 0 && categoriesData.length === 0) {
        console.warn('⚠️ No data found in Firestore. Please add sample data through Firebase Console or API.');
        setError('No data available. Please contact support.');
      }
    } catch (err) {
      console.error('❌ Error loading home data from Firestore:', err);
      setError('Failed to load data from server');
      setPopularProducts([]);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const refresh = useCallback(async () => {
    console.log('🔄 Refreshing home data...');
    await loadHomeData();
  }, [loadHomeData]);

  useEffect(() => {
    loadHomeData();
  }, [loadHomeData]);

  return {
    popularProducts,
    categories,
    loading,
    error,
    refresh,
  };
};

export default useHomeData;
