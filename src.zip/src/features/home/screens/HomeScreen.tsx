import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  RefreshControl,
  Alert,
  StyleSheet,
  Animated,
  Dimensions,
  ViewStyle,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaWrapper, Header, SectionHeader } from '../../../components/layout';
import { ServiceTabs, PromoBanner } from '../../../components/layout';
import { Button, Card } from '../../../components/common';
import { useThemeContext } from '../../../contexts/ThemeContext';
import { useHomeData } from '../hooks/useHomeData';
import CategorySection from '../../../components/layout/CategorySection';
import {
  getCategoriesByService,
  getProductsByServiceAndCategory,
  ProductData,
  ProductCategory
} from '../../../services/firebase/firestore/productService';
import LottieView from 'lottie-react-native';

const { width: screenWidth } = Dimensions.get('window');

interface Service {
  id: string;
  name: string;
  icon: string;
  description: string;
}

// Helper function to get categories for a service (synchronous, with async inside)
const getServiceCategoriesData = (serviceId: string): ProductCategory[] => {
  // For synchronous usage, we'll use static fallback for now
  // In a real app, you might want to fetch this in useEffect and store in state
  return getStaticCategoriesFallback(serviceId);
};

// Fallback static categories if dynamic fetch fails
const getStaticCategoriesFallback = (serviceId: string): ProductCategory[] => {
  const categoriesMap = {
    fresh: [
      { id: 'salads', name: 'Salads', icon: '🥗', productCount: 25, isActive: true, description: 'Fresh salads' },
      { id: 'curries', name: 'Curries', icon: '🍛', productCount: 30, isActive: true, description: 'Indian curries' },
    ],
    fmcg: [
      { id: 'snacks', name: 'Snacks', icon: '🍟', productCount: 20, isActive: true, description: 'Crispy snacks' },
      { id: 'beverages', name: 'Beverages', icon: '🥤', productCount: 35, isActive: true, description: 'Drinks' },
    ],
    supplies: [
      { id: 'stationery', name: 'Stationery', icon: '📝', productCount: 30, isActive: true, description: 'Office supplies' },
      { id: 'electronics', name: 'Electronics', icon: '💻', productCount: 15, isActive: true, description: 'Tech items' },
    ],
  };
  return categoriesMap[serviceId as keyof typeof categoriesMap] || [];
};

export const HomeScreen: React.FC = () => {
  const { theme } = useThemeContext();
  const { categories, loading, error, refresh } = useHomeData();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeService, setActiveService] = useState('all');
  const [serviceCategories, setServiceCategories] = useState<ProductCategory[]>([]);
  const [categoryProducts, setCategoryProducts] = useState<{[categoryId: string]: ProductData[]}>({});
  const [categoriesLoading, setCategoriesLoading] = useState(false);
  const navigation = useNavigation<any>();

  // Load categories when activeService changes
  useEffect(() => {
    const loadCategories = async () => {
      setCategoriesLoading(true);
      try {
        if (activeService === 'all') {
          const [freshCats, fmcgCats, suppliesCats] = await Promise.all([
            getCategoriesByService('fresh'),
            getCategoriesByService('fmcg'),
            getCategoriesByService('supplies'),
          ]);
          setServiceCategories([...freshCats, ...fmcgCats, ...suppliesCats]);
        } else {
          const cats = await getCategoriesByService(activeService as 'fresh' | 'fmcg' | 'supplies');
          setServiceCategories(cats);
        }
      } catch (err) {
        console.error('Error loading categories:', err);
        setServiceCategories([]);
      } finally {
        setCategoriesLoading(false);
      }
    };
    loadCategories();
  }, [activeService]);

  const handleServicePress = async (service: any) => {
    setActiveService(service.id);

    if (service.id !== 'all') {
      try {
        setCategoriesLoading(true);
        const categories = await getCategoriesByService(service.id as 'fresh' | 'fmcg' | 'supplies');
        setServiceCategories(categories);

        // Load products for each category
        const productsPromises = categories.map(async (category) => {
          const products = await getProductsByServiceAndCategory(
            service.id as 'fresh' | 'fmcg' | 'supplies',
            category.id,
            10
          );
          return { categoryId: category.id, products };
        });

        const productsResults = await Promise.all(productsPromises);
        const productsMap: {[categoryId: string]: ProductData[]} = {};
        productsResults.forEach(result => {
          productsMap[result.categoryId] = result.products;
        });
        setCategoryProducts(productsMap);
      } catch (error) {
        console.error('Error loading service categories:', error);
      } finally {
        setCategoriesLoading(false);
      }
    } else {
      setServiceCategories([]);
      setCategoryProducts({});
    }
  };

  const handleProductPress = (product: any) => {
    navigation.navigate('ProductDetails', { productId: product.id });
  };

  const handleCategoryPress = (category: any) => {
    navigation.navigate('Product', { category: category.name });
  };

  const handleSeeAllPress = (categoryName: string) => {
    navigation.navigate('Product', { category: categoryName });
  };

  const handleRefresh = async () => {
    await refresh();
    if (!error) {
      Alert.alert('Refreshed', 'Data has been updated from Firestore!');
    }
  };

  const renderLoadingAnimation = () => (
    <View style={styles.loadingContainer}>
      <LottieView
        source={require('../../../assets/animations/loading.json')}
        autoPlay
        loop
        style={styles.loadingAnimation}
      />
      <Text style={[styles.loadingText, { color: theme.colors.textSecondary }]}>
        Loading products...
      </Text>
    </View>
  );

  const renderErrorState = () => (
    <Card style={styles.errorCard}>
      <Text style={styles.errorTitle}>Connection Issue</Text>
      <Text style={styles.errorText}>{error}</Text>
      <Text style={styles.errorSubtext}>
        Please check your internet connection and try again.
      </Text>
      <Button
        title="Retry"
        onPress={handleRefresh}
        style={styles.retryButton}
        variant="outline"
      />
    </Card>
  );

  const renderEmptyState = () => (
    <Card style={styles.emptyStateCard}>
      <Text style={styles.emptyTitle}>No Products Available</Text>
      <Text style={styles.emptyText}>
        No products or categories are available right now.
      </Text>
      <Text style={styles.emptySubtext}>
        Please contact the administrator to add products and categories.
      </Text>
      <Button
        title="Check Again"
        onPress={handleRefresh}
        style={styles.retryButton}
      />
    </Card>
  );

  const services: Service[] = [
    { id: 'all', name: 'All', icon: '🏪', description: 'All services' },
    { id: 'fresh', name: 'Fresh Serve', icon: '🥬', description: 'Fresh produce and meals' },
    { id: 'fmcg', name: 'FMCG', icon: '🛒', description: 'Fast-moving consumer goods' },
    { id: 'supplies', name: 'Supplies', icon: '📦', description: 'Business and office supplies' },
  ];

  const transformedServices = services.map(service => ({
    id: service.id,
    name: service.name,
    icon: service.icon,
    description: service.description,
    isActive: activeService === service.id,
  }));

  return (
    <SafeAreaWrapper style={styles.safeArea}>
      {/* Header */}
      <Header
        title=""
        leftComponent={
          <TouchableOpacity style={styles.locationButton} onPress={() => Alert.alert('Location', 'GPS location')}>
            <Text style={styles.locationIcon}>📍</Text>
            <Text style={[styles.locationText, { color: theme.colors.text }]}>
              Mumbai, India
            </Text>
          </TouchableOpacity>
        }
        rightComponent={
          <TouchableOpacity style={styles.profileButton} onPress={() => Alert.alert('Profile', 'User profile')}>
            <Text style={styles.profileIcon}>👤</Text>
          </TouchableOpacity>
        }
        variant="transparent"
        style={styles.header}
      />

      {/* Main Content */}
      <View style={styles.mainContainer}>
        <ScrollView
          style={styles.scrollView}
          refreshControl={
            <RefreshControl refreshing={loading} onRefresh={handleRefresh} />
          }
          showsVerticalScrollIndicator={false}
        >
          {/* Search Bar */}
          <View style={styles.searchSection}>
            <View style={[styles.searchContainer, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
              <Text style={[styles.searchIcon, { color: theme.colors.textSecondary }]}>
                🔍
              </Text>
              <TextInput
                style={[styles.searchInput, { color: theme.colors.text }]}
                placeholder="Search products, categories..."
                placeholderTextColor={theme.colors.textSecondary}
                value={searchQuery}
                onChangeText={setSearchQuery}
                returnKeyType="search"
              />
            </View>
          </View>

          {/* Service Tabs */}
          <ServiceTabs
            services={transformedServices}
            onServicePress={handleServicePress}
            variant="default"
            size="medium"
          />

          {/* Promo Banner */}
          <PromoBanner
            title="Fresh Deals Every Day!"
            subtitle="Up to 30% off on organic produce"
            backgroundColor={theme.colors.primary}
            textColor={theme.colors.white}
            onPress={() => Alert.alert('Promo', 'Navigate to special offers')}
            variant="default"
          />

          {/* Categories Section for All Services */}
          {activeService === 'all' && (
            <View>
              {services.filter(service => service.id !== 'all').map((service) => (
                <View key={service.id} style={styles.serviceSection}>
                  <SectionHeader
                    title={service.name}
                    subtitle={`Shop by ${service.name.toLowerCase()} categories`}
                  />
                  <View style={styles.categoriesContainer}>
                    {getServiceCategoriesData(service.id).map((category: ProductCategory) => (
                      <TouchableOpacity
                        key={category.id}
                        style={[styles.categoryItem, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}
                        onPress={() => handleCategoryPress(category)}
                      >
                        <Text style={[styles.categoryIcon, { fontSize: 24 }]}>
                          {category.icon}
                        </Text>
                        <View style={styles.categoryInfo}>
                          <Text style={[styles.categoryName, { color: theme.colors.text }]}>
                            {category.name}
                          </Text>
                          <Text style={[styles.categoryCount, { color: theme.colors.textSecondary }]}>
                            {category.productCount} items
                          </Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              ))}
            </View>
          )}

          {/* Service-specific Categories */}
          {activeService !== 'all' && (
            <View style={styles.serviceSection}>
              <SectionHeader
                title={services.find(s => s.id === activeService)?.name || 'Service'}
                subtitle={`Shop by ${activeService} categories`}
              />

              {serviceCategories.map((category) => (
                <CategorySection
                  key={category.id}
                  title={category.name}
                  products={categoryProducts[category.id] || []}
                  onProductPress={handleProductPress}
                  onSeeAllPress={() => handleSeeAllPress(category.name)}
                  service={activeService as 'fresh' | 'fmcg' | 'supplies'}
                />
              ))}
            </View>
          )}

          {/* Bottom Spacing */}
          <View style={styles.bottomSpacing} />
        </ScrollView>
      </View>
    </SafeAreaWrapper>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  mainContainer: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    backgroundColor: 'transparent',
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  locationIcon: {
    fontSize: 14,
    marginRight: 4,
  },
  locationText: {
    fontSize: 12,
    fontWeight: '500',
  },
  profileButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  profileIcon: {
    fontSize: 16,
  },
  searchSection: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 12,
    minHeight: 48,
  },
  searchIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 0,
  },
  // Loading Animation Styles
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  loadingAnimation: {
    width: 100,
    height: 100,
  },
  loadingText: {
    fontSize: 16,
    marginTop: 16,
    textAlign: 'center',
  },
  // Error State Styles
  errorCard: {
    margin: 16,
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#ffebee',
    borderLeftWidth: 4,
    borderLeftColor: '#f44336',
  },
  errorTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#d32f2f',
    marginTop: 16,
    marginBottom: 8,
  },
  errorText: {
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  errorSubtext: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    alignSelf: 'center',
  },
  // Empty State Styles
  emptyStateCard: {
    margin: 16,
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#e8eaf6',
    borderLeftWidth: 4,
    borderLeftColor: '#3f51b5',
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#3f51b5',
    marginTop: 16,
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 16,
  },
  serviceSection: {
    marginBottom: 24,
  },
  categoriesContainer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  categoryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderRadius: 12,
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  categoryIcon: {
    fontSize: 24,
    marginRight: 12,
    width: 40,
    textAlign: 'center',
  },
  categoryName: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
  },
  categoryCount: {
    fontSize: 12,
    fontWeight: '500',
  },
  categoryInfo: {
    flex: 1,
    marginLeft: 12,
  },
  bottomSpacing: {
    height: 100,
  },
});

export default HomeScreen;
