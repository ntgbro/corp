import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useTheme } from '../../../config/theme';

interface Category {
  id: string;
  name: string;
  icon?: string;
  description?: string;
  productCount?: number;
}

interface CategorySliderProps {
  categories: Category[];
  selectedCategory?: string;
  onCategoryPress?: (category: Category) => void;
  style?: any;
  showProductCount?: boolean;
}

export const CategorySlider: React.FC<CategorySliderProps> = ({
  categories,
  selectedCategory,
  onCategoryPress,
  style,
  showProductCount = true,
}) => {
  const theme = useTheme();
  const [selectedId, setSelectedId] = useState(selectedCategory || categories[0]?.id);

  const handleCategoryPress = (category: Category) => {
    setSelectedId(category.id);
    onCategoryPress?.(category);
  };

  return (
    <View style={[styles.container, style]}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.listContainer}
      >
        {categories.map((item) => {
          const isSelected = selectedId === item.id;

          return (
            <TouchableOpacity
              key={item.id}
              style={[
                styles.categoryItem,
                {
                  backgroundColor: isSelected ? theme.colors.primary : theme.colors.surface,
                  borderColor: isSelected ? theme.colors.primary : theme.colors.border,
                },
              ]}
              onPress={() => handleCategoryPress(item)}
              activeOpacity={0.7}
            >
              <View style={styles.categoryContent}>
                {item.icon && (
                  <Text style={[styles.categoryIcon, {
                    color: isSelected ? theme.colors.white : theme.colors.primary,
                  }]}>
                    {item.icon}
                  </Text>
                )}

                <Text
                  style={[
                    styles.categoryName,
                    {
                      color: isSelected ? theme.colors.white : theme.colors.text,
                      fontWeight: isSelected ? '600' : '400',
                    },
                  ]}
                  numberOfLines={1}
                >
                  {item.name}
                </Text>

                {showProductCount && item.productCount !== undefined && (
                  <Text
                    style={[
                      styles.productCount,
                      {
                        color: isSelected ? `${theme.colors.white}CC` : theme.colors.textSecondary,
                      },
                    ]}
                  >
                    {item.productCount} items
                  </Text>
                )}
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 12,
  },
  listContainer: {
    paddingHorizontal: 16,
    gap: 12,
  },
  categoryItem: {
    borderWidth: 1,
    borderRadius: 24,
    paddingVertical: 8,
    paddingHorizontal: 16,
    minWidth: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  categoryName: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 2,
  },
  productCount: {
    fontSize: 12,
    textAlign: 'center',
  },
});

export default CategorySlider;
