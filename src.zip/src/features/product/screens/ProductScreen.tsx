import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import type { RouteProp } from '@react-navigation/native';
import { SafeAreaWrapper, Header, ProductGrid } from '../../../components/layout';
import { Button } from '../../../components/common';
import { useTheme } from '../../../config/theme';
import { Alert } from 'react-native';
import { TouchableOpacity } from 'react-native';
import { productService } from '../../../services/firebase/firestore/productService';
import { ProductData } from '../../../components/layout/ProductCard';

type ProductScreenRouteProp = RouteProp<{ Product: { category: string } }, 'Product'>;

export const ProductScreen: React.FC = () => {
  const theme = useTheme();
  const route = useRoute<ProductScreenRouteProp>();
  const navigation = useNavigation();
  const { category } = route.params;

  const [products, setProducts] = useState<ProductData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);
        console.log(`🔥 Loading products for category: ${category}`);

        // Get all products and filter by category
        const allProducts = await productService.getProductsByCategory(category);
        console.log(`✅ Loaded ${allProducts.length} products for category: ${category}`);
        console.log('📱 Products data:', allProducts.slice(0, 5)); // Log first 5 products for debugging
        console.log('🔍 Searching for category:', category);

        setProducts(allProducts);
      } catch (error) {
        console.error('Error loading products:', error);
        setError('Failed to load products');
        Alert.alert('Error', 'Failed to load products');
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, [category]);

  const handleProductPress = (product: any) => {
    // Navigate to ProductDetailScreen with product ID
    (navigation as any).navigate('ProductDetails', { productId: product.id });
  };

  const handleRetry = () => {
    setError(null);
    setLoading(true);
    // Reload products
    const loadProducts = async () => {
      try {
        const allProducts = await productService.getProductsByCategory(category);
        setProducts(allProducts);
      } catch (error) {
        setError('Failed to load products');
      } finally {
        setLoading(false);
      }
    };
    loadProducts();
  };

  const renderLoading = () => (
    <View style={styles.loadingContainer}>
      <Text style={[styles.loadingText, { color: theme.colors.textSecondary }]}>
        Loading {category} products...
      </Text>
    </View>
  );

  const renderError = () => (
    <View style={styles.errorContainer}>
      <Text style={styles.errorTitle}>Connection Issue</Text>
      <Text style={styles.errorText}>{error}</Text>
      <Text style={styles.errorSubtext}>
        Please check your internet connection and try again.
      </Text>
      <Button
        title="Retry"
        onPress={handleRetry}
        style={styles.retryButton}
        variant="outline"
      />
    </View>
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyTitle}>No Products Found</Text>
      <Text style={styles.emptyText}>
        No products available in {category} category.
      </Text>
      <Button
        title="Go Back"
        onPress={() => console.log('Go back')}
        style={styles.backButton}
      />
    </View>
  );

  return (
    <SafeAreaWrapper style={{ flex: 1 }}>
      <View style={{ flex: 1 }}>
        <Header
          title={`${category} Products`}
          showBackButton
          onBackPress={() => console.log('Go back')}
        />

        {loading ? (
          renderLoading()
        ) : error ? (
          renderError()
        ) : products.length === 0 ? (
          renderEmpty()
        ) : (
          <ProductGrid
            products={products}
            onProductPress={handleProductPress}
            numColumns={2}
            showRating={true}
            showCategory={false}
            cardSize="medium"
            style={{ flex: 1 }}
          />
        )}
      </View>
    </SafeAreaWrapper>
  );
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  loadingText: {
    fontSize: 16,
    marginTop: 16,
    textAlign: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  errorSubtext: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    alignSelf: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  backButton: {
    alignSelf: 'center',
  },
});

export default ProductScreen;
