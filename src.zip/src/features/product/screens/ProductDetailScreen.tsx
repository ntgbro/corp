import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Alert,
  Dimensions,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import type { RouteProp } from '@react-navigation/native';
import { MainStackParamList } from '../../../navigation/types';
import { SafeAreaWrapper, Header } from '../../../components/layout';
import { Button, Card } from '../../../components/common';
import { useThemeContext } from '../../../contexts/ThemeContext';
import { useCart } from '../../../contexts/CartContext';
import { productService, ProductData } from '../../../services/firebase/firestore/productService';

const { width: screenWidth } = Dimensions.get('window');

type ProductDetailRouteProp = RouteProp<MainStackParamList, 'ProductDetails'>;

export const ProductDetailScreen: React.FC = () => {
  const { theme } = useThemeContext();
  const route = useRoute<ProductDetailRouteProp>();
  const navigation = useNavigation();
  const { addToCart } = useCart();

  const { productId } = route.params;

  const [product, setProduct] = useState<ProductData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const loadProduct = async () => {
      try {
        setLoading(true);
        console.log(`🔍 Loading product details for ID: ${productId}`);

        const productData = await productService.getProductById(productId);

        if (!productData) {
          setError('Product not found');
          return;
        }

        setProduct(productData);
        console.log(`✅ Loaded product: ${productData.name}`);
      } catch (err) {
        console.error('❌ Error loading product details:', err);
        setError('Failed to load product details');
      } finally {
        setLoading(false);
      }
    };

    if (productId) {
      loadProduct();
    }
  }, [productId]);

  const handleAddToCart = () => {
    if (!product) return;

    // Create cart item matching CartContext interface
    const cartItem = {
      id: `${product.id}_${Date.now()}`, // Unique cart item ID
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.image || '',
      chefId: 'default-chef', // This should come from product data
      chefName: 'Default Chef', // This should come from product data
    };

    addToCart(cartItem);

    Alert.alert(
      'Added to Cart',
      `${quantity} x ${product.name} has been added to your cart`,
      [
        { text: 'Continue Shopping' },
        { text: 'View Cart', onPress: () => navigation.navigate('Cart' as never) }
      ]
    );
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= 10) {
      setQuantity(newQuantity);
    }
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push('★');
    }

    if (hasHalfStar) {
      stars.push('☆');
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push('☆');
    }

    return stars.join('');
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(price);
  };

  if (loading) {
    return (
      <SafeAreaWrapper style={{ flex: 1 }}>
        <Header title="Product Details" showBackButton />
        <View style={[styles.loadingContainer, { backgroundColor: theme.colors.background }]}>
          <Text style={[styles.loadingText, { color: theme.colors.textSecondary }]}>
            Loading product details...
          </Text>
        </View>
      </SafeAreaWrapper>
    );
  }

  if (error || !product) {
    return (
      <SafeAreaWrapper style={{ flex: 1 }}>
        <Header title="Product Details" showBackButton />
        <View style={[styles.errorContainer, { backgroundColor: theme.colors.background }]}>
          <Text style={[styles.errorText, { color: theme.colors.error }]}>
            {error || 'Product not found'}
          </Text>
          <Button
            title="Go Back"
            onPress={() => navigation.goBack()}
            style={styles.retryButton}
            variant="outline"
          />
        </View>
      </SafeAreaWrapper>
    );
  }

  return (
    <SafeAreaWrapper style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <Header title="Product Details" showBackButton />

      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Product Image */}
        <View style={styles.imageContainer}>
          {product.image ? (
            <Image
              source={{ uri: product.image }}
              style={styles.productImage}
              resizeMode="cover"
            />
          ) : (
            <View style={[styles.productImage, styles.placeholderImage, { backgroundColor: theme.colors.surface }]}>
              <Text style={[styles.placeholderText, { color: theme.colors.textSecondary }]}>
                No Image
              </Text>
            </View>
          )}

          {/* Availability Badge */}
          {!product.isAvailable && (
            <View style={[styles.badge, styles.unavailableBadge, { backgroundColor: theme.colors.error }]}>
              <Text style={[styles.badgeText, { color: theme.colors.white }]}>
                Out of Stock
              </Text>
            </View>
          )}
        </View>

        {/* Product Info Card */}
        <Card style={styles.infoCard}>
          {/* Category */}
          {product.category && (
            <Text style={[styles.category, { color: theme.colors.primary }]}>
              {product.category}
            </Text>
          )}

          {/* Product Name */}
          <Text style={[styles.title, { color: theme.colors.text }]}>
            {product.name}
          </Text>

          {/* Rating and Reviews */}
          {product.rating !== undefined && (
            <View style={styles.ratingContainer}>
              <Text style={[styles.stars, { color: '#FFD700' }]}>
                {renderStars(product.rating)}
              </Text>
              <Text style={[styles.ratingText, { color: theme.colors.textSecondary }]}>
                {product.rating.toFixed(1)}
              </Text>
              {product.reviewCount !== undefined && (
                <Text style={[styles.reviewCount, { color: theme.colors.textSecondary }]}>
                  ({product.reviewCount} reviews)
                </Text>
              )}
            </View>
          )}

          {/* Description */}
          {product.description && (
            <View style={styles.descriptionContainer}>
              <Text style={[styles.descriptionTitle, { color: theme.colors.text }]}>
                Description
              </Text>
              <Text style={[styles.description, { color: theme.colors.textSecondary }]}>
                {product.description}
              </Text>
            </View>
          )}
        </Card>

        {/* Quantity Selector */}
        <Card style={styles.quantityCard}>
          <Text style={[styles.quantityTitle, { color: theme.colors.text }]}>
            Quantity
          </Text>
          <View style={styles.quantityControls}>
            <TouchableOpacity
              style={[styles.quantityButton, { borderColor: theme.colors.border }]}
              onPress={() => handleQuantityChange(quantity - 1)}
              disabled={quantity <= 1}
            >
              <Text style={[styles.quantityButtonText, { color: quantity <= 1 ? theme.colors.textSecondary : theme.colors.primary }]}>
                −
              </Text>
            </TouchableOpacity>

            <Text style={[styles.quantityText, { color: theme.colors.text }]}>
              {quantity}
            </Text>

            <TouchableOpacity
              style={[styles.quantityButton, { borderColor: theme.colors.border }]}
              onPress={() => handleQuantityChange(quantity + 1)}
              disabled={quantity >= 10}
            >
              <Text style={[styles.quantityButtonText, { color: quantity >= 10 ? theme.colors.textSecondary : theme.colors.primary }]}>
                +
              </Text>
            </TouchableOpacity>
          </View>
        </Card>

        {/* Price and Add to Cart */}
        <Card style={styles.priceCard}>
          <View style={styles.priceContainer}>
            <View>
              <Text style={[styles.priceLabel, { color: theme.colors.textSecondary }]}>
                Total Price
              </Text>
              <Text style={[styles.price, { color: theme.colors.primary }]}>
                {formatPrice(product.price * quantity)}
              </Text>
            </View>

            <Button
              title="Add to Cart"
              onPress={handleAddToCart}
              disabled={!product.isAvailable}
              style={styles.addToCartButton}
            />
          </View>
        </Card>

        {/* Bottom spacing */}
        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaWrapper>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  loadingText: {
    fontSize: 16,
    marginTop: 16,
    textAlign: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    textAlign: 'center',
  },
  retryButton: {
    alignSelf: 'center',
  },
  imageContainer: {
    position: 'relative',
    width: screenWidth,
    height: screenWidth * 0.75, // 3:4 aspect ratio
  },
  productImage: {
    width: '100%',
    height: '100%',
  },
  placeholderImage: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    fontSize: 16,
    fontWeight: '500',
  },
  badge: {
    position: 'absolute',
    top: 16,
    right: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  unavailableBadge: {
    backgroundColor: '#FF3B30',
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#fff',
  },
  infoCard: {
    margin: 16,
    padding: 16,
  },
  category: {
    fontSize: 14,
    fontWeight: '600',
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 12,
    lineHeight: 28,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  stars: {
    fontSize: 16,
    marginRight: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    marginRight: 8,
  },
  reviewCount: {
    fontSize: 14,
  },
  descriptionContainer: {
    marginTop: 8,
  },
  descriptionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  description: {
    fontSize: 14,
    lineHeight: 20,
  },
  quantityCard: {
    margin: 16,
    marginTop: 0,
    padding: 16,
  },
  quantityTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantityButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 16,
  },
  quantityButtonText: {
    fontSize: 20,
    fontWeight: '600',
  },
  quantityText: {
    fontSize: 18,
    fontWeight: '600',
    minWidth: 40,
    textAlign: 'center',
  },
  priceCard: {
    margin: 16,
    marginTop: 0,
    padding: 16,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  price: {
    fontSize: 24,
    fontWeight: '700',
  },
  addToCartButton: {
    minWidth: 140,
  },
  bottomSpacing: {
    height: 100,
  },
});

export default ProductDetailScreen;
