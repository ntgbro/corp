// Screens
export { default as ProductDetailScreen } from './screens/ProductDetailScreen';
export { default as ProductScreen } from './screens/ProductScreen';

// Re-export ProductData for convenience
export type { ProductData } from '../../../services/firebase/firestore/productService';
