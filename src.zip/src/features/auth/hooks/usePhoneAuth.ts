import { useState, useCallback } from 'react';
import { authService } from '../../../services/firebase/auth/authService';

export interface UsePhoneAuthReturn {
  sendOTP: (phoneNumber: string) => Promise<{ success: boolean; error?: string }>;
  verifyOTP: (confirm: any, code: string) => Promise<{ user: any; error?: string }>;
  signOut: () => Promise<void>;
  loading: boolean;
  error: string | null;
}

export const usePhoneAuth = (): UsePhoneAuthReturn => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendOTP = useCallback(async (phoneNumber: string) => {
    try {
      setLoading(true);
      setError(null);
      const result = await authService.sendOTP(phoneNumber);
      return { success: !!result.confirm, error: result.error };
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to send OTP';
      setError(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);

  const verifyOTP = useCallback(async (confirm: any, code: string) => {
    try {
      setLoading(true);
      setError(null);

      if (!confirm) {
        throw new Error('No confirmation object available');
      }

      if (!code || code.length !== 6) {
        throw new Error('Please enter a valid 6-digit OTP');
      }

      const result = await authService.verifyOTP(code);
      return result;
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to verify OTP';
      setError(errorMessage);
      return { user: null, error: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await authService.signOut();
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to sign out';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    sendOTP,
    verifyOTP,
    signOut,
    loading,
    error,
  };
};

export default usePhoneAuth;
