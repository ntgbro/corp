import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp, CommonActions } from '@react-navigation/native';
import { AuthStackParamList } from '../../../navigation/types';
import { SafeAreaWrapper, Header } from '../../../components/layout';
import { Button, TextInput, Card } from '../../../components/common';
import { authService, OTPVerificationResult } from '../../../services/firebase/auth/authService';
import { ResendOTPButton } from '../components/ResendOTPButton';
import { useResendCountdown } from '../hooks/useResendCountdown';

type OTPVerificationScreenNavigationProp = StackNavigationProp<AuthStackParamList, 'OTPVerification'>;
type OTPVerificationScreenRouteProp = RouteProp<AuthStackParamList, 'OTPVerification'>;

const OTPVerificationScreen: React.FC = () => {
  const [otp, setOtp] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const navigation = useNavigation<OTPVerificationScreenNavigationProp>();
  const route = useRoute<OTPVerificationScreenRouteProp>();
  const inputRef = useRef<any>(null);

  const { phoneNumber } = route.params;

  // Debug logging
  console.log('OTPVerificationScreen - PhoneNumber:', phoneNumber);
  console.log('OTPVerificationScreen - Using stored confirmation object');

  // Use the countdown hook
  const { countdown, canResend, startCountdown, resetCountdown } = useResendCountdown(30);

  // Auto-focus OTP input on mount
  useEffect(() => {
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  }, []);

  const handleOtpChange = (text: string): void => {
    const numericText = text.replace(/[^0-9]/g, '');
    setOtp(numericText.substring(0, 6));
  };

  const handleVerifyOTP = async (): Promise<void> => {
    if (!otp || otp.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP code');
      return;
    }

    setLoading(true);

    try {
      console.log('Verifying OTP...');
      const confirmation = authService.getCurrentConfirmation();
      console.log('Current confirmation object:', confirmation ? 'Exists' : 'Null');

      if (!confirmation) {
        throw new Error('No confirmation object found. Please request a new OTP.');
      }

      console.log('Confirming OTP with code:', otp);
      const result: OTPVerificationResult = await authService.verifyOTP(otp);

      if (result.error) {
        console.error('OTP Verification Error:', result.error);
        Alert.alert('Verification Failed', result.error || 'Failed to verify OTP');
      } else if (result.user) {
        console.log('OTP Verification Successful for user:', result.user.uid);
        
        // Navigate to main app without showing an alert first
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{ name: 'Main' }],
          })
        );
      }
    } catch (error: any) {
      console.error('OTP Verification Exception:', {
        code: error?.code,
        message: error?.message,
        stack: error?.stack
      });
      
      let errorMessage = 'Failed to verify OTP. Please try again.';
      
      // Handle specific Firebase errors
      if (error.code) {
        switch (error.code) {
          case 'auth/invalid-verification-code':
            errorMessage = 'The verification code is invalid. Please check and try again.';
            break;
          case 'auth/code-expired':
            errorMessage = 'The verification code has expired. Please request a new one.';
            break;
          case 'auth/too-many-requests':
            errorMessage = 'Too many attempts. Please try again later.';
            break;
        }
      }
      
      Alert.alert('Verification Failed', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async (): Promise<void> => {
    setLoading(true);

    try {
      const result = await authService.sendOTP(phoneNumber);

      if (result.error) {
        Alert.alert('Error', result.error);
      } else {
        Alert.alert('Success', 'OTP sent successfully!');
        startCountdown(30); // Reset countdown
      }
    } catch (error: any) {
      Alert.alert('Error', 'Failed to resend OTP. Please try again.');
      console.error('Resend OTP error:', error?.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaWrapper>
      <Header
        title="Verify Your Number"
        showBackButton
        onBackPress={() => navigation.goBack()}
      />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <Card style={styles.contentCard}>
            <Text style={styles.subtitle}>
              Enter the 6-digit code sent to{'\n'}
              <Text style={styles.phoneNumber}>{phoneNumber}</Text>
            </Text>

            <TextInput
              ref={inputRef}
              label="OTP Code"
              value={otp}
              onChangeText={handleOtpChange}
              placeholder="000000"
              keyboardType="numeric"
              maxLength={6}
              style={styles.otpInput}
            />

            <Button
              title={loading ? 'Verifying...' : 'Verify OTP'}
              onPress={handleVerifyOTP}
              loading={loading}
              disabled={!otp || otp.length !== 6 || loading}
              size="large"
              style={styles.verifyButton}
            />

            <ResendOTPButton
              onResend={handleResendOTP}
              cooldownTime={30}
              disabled={loading}
              style={styles.resendButton}
            />

            <Button
              title="Change Phone Number"
              onPress={() => navigation.goBack()}
              variant="secondary"
              disabled={loading}
            />
          </Card>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaWrapper>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  contentCard: {
    alignItems: 'center',
    padding: 24,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 40,
    textAlign: 'center',
  },
  phoneNumber: {
    fontWeight: 'bold',
    color: '#333',
  },
  otpInput: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    letterSpacing: 4,
  },
  verifyButton: {
    width: '100%',
    marginBottom: 16,
  },
  resendButton: {
    width: '100%',
    marginBottom: 16,
  },
});

export default OTPVerificationScreen;
