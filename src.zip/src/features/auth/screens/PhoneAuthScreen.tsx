import React from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { AuthStackParamList } from '../../../navigation/types';
import { SafeAreaWrapper } from '../../../components/layout';
import { PhoneAuthForm } from '../components/PhoneAuthForm';

type PhoneAuthScreenNavigationProp = StackNavigationProp<AuthStackParamList, 'PhoneAuth'>;

const PhoneAuthScreen: React.FC = () => {
  const navigation = useNavigation<PhoneAuthScreenNavigationProp>();

  const handleOTPSent = (phoneNumber: string) => {
    console.log('OTP sent to:', phoneNumber);
    navigation.navigate('OTPVerification', {
      phoneNumber,
      confirm: null, // No longer passing confirm object
    });
  };

  const handleError = (error: string) => {
    console.error('PhoneAuthForm error:', error);
    // Error handling is already done in PhoneAuthForm
  };

  return (
    <SafeAreaWrapper>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <PhoneAuthForm
            onOTPSent={handleOTPSent}
            onError={handleError}
            loading={false}
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaWrapper>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
});

export default PhoneAuthScreen;
