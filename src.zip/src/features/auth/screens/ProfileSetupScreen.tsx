import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../../../config';
import { useNavigation } from '@react-navigation/native';
import { Avatar, Button } from '../../../components/common';
import { authService } from '../../../services/firebase/auth/authService';
import { userService } from '../../../services/firebase/firestore/userService';

export interface ProfileSetupScreenProps {
  route: {
    params: {
      userId: string;
      phoneNumber: string;
    };
  };
}

export const ProfileSetupScreen: React.FC<ProfileSetupScreenProps> = ({ route }) => {
  const theme = useTheme();
  const navigation = useNavigation();
  const { userId, phoneNumber } = route.params;

  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [avatar, setAvatar] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    if (!displayName.trim()) {
      Alert.alert('Error', 'Please enter your name');
      return false;
    }
    if (email && !/\S+@\S+\.\S+/.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return false;
    }
    return true;
  };

  const handleCompleteSetup = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      // Update user profile
      await userService.createUserProfile(userId, {
        phoneNumber,
        displayName: displayName.trim(),
        role: 'customer',
      });

      // Navigate to main app
      // navigation.navigate('Main' as never);

      Alert.alert(
        'Success',
        'Profile setup completed successfully!',
        [
          {
            text: 'Continue',
            onPress: () => {
              // Navigate to main app
              console.log('Profile setup completed for user:', userId);
            },
          },
        ]
      );
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to complete setup');
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = () => {
    Alert.alert(
      'Skip Setup',
      'You can complete your profile setup later from the settings.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Skip',
          style: 'destructive',
          onPress: () => {
            // Navigate to main app without completing setup
            console.log('Profile setup skipped for user:', userId);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.colors.text }]}>
            Complete Your Profile
          </Text>
          <Text style={[styles.subtitle, { color: theme.colors.textSecondary }]}>
            Help us personalize your experience
          </Text>
        </View>

        <View style={styles.avatarSection}>
          <Avatar
            source={avatar}
            name={displayName || 'User'}
            size="xlarge"
            style={styles.avatar}
          />
          <TouchableOpacity
            style={[styles.avatarButton, { borderColor: theme.colors.primary }]}
            onPress={() => {
              // Handle avatar selection
              console.log('Avatar selection');
            }}
          >
            <Text style={[styles.avatarButtonText, { color: theme.colors.primary }]}>
              Change Photo
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.form}>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, { color: theme.colors.text }]}>Full Name *</Text>
            <TextInput
              style={[styles.input, { color: theme.colors.text, borderColor: theme.colors.border }]}
              value={displayName}
              onChangeText={setDisplayName}
              placeholder="Enter your full name"
              placeholderTextColor={theme.colors.textSecondary}
              autoCapitalize="words"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={[styles.label, { color: theme.colors.text }]}>Email (Optional)</Text>
            <TextInput
              style={[styles.input, { color: theme.colors.text, borderColor: theme.colors.border }]}
              value={email}
              onChangeText={setEmail}
              placeholder="Enter your email"
              placeholderTextColor={theme.colors.textSecondary}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
        </View>

        <View style={styles.buttons}>
          <Button
            title="Complete Setup"
            onPress={handleCompleteSetup}
            loading={loading}
            style={styles.completeButton}
          />

          <TouchableOpacity
            style={[styles.skipButton, { borderColor: theme.colors.border }]}
            onPress={handleSkip}
          >
            <Text style={[styles.skipButtonText, { color: theme.colors.textSecondary }]}>
              Skip for now
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
  },
  avatarSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  avatar: {
    marginBottom: 16,
  },
  avatarButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderWidth: 1,
    borderRadius: 20,
  },
  avatarButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  form: {
    marginBottom: 32,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
  },
  buttons: {
    gap: 16,
  },
  completeButton: {
    marginBottom: 16,
  },
  skipButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderWidth: 1,
    borderRadius: 12,
    alignItems: 'center',
  },
  skipButtonText: {
    fontSize: 16,
    fontWeight: '500',
  },
});

export default ProfileSetupScreen;
