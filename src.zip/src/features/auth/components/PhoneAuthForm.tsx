import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Animated,
  Dimensions,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { useTheme } from '../../../config';
import { COUNTRY_CODES } from '../../../config';
import { authService } from '../../../services/firebase/auth/authService';

export interface PhoneAuthFormProps {
  onOTPSent: (phoneNumber: string) => void;
  onError: (error: string) => void;
  loading?: boolean;
}

export const PhoneAuthForm: React.FC<PhoneAuthFormProps> = ({
  onOTPSent,
  onError,
  loading = false,
}) => {
  const theme = useTheme();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(COUNTRY_CODES[0]);
  const [isLoading, setIsLoading] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [showCountryPicker, setShowCountryPicker] = useState(false);

  // Premium animation values
  const fadeInValue = useState(new Animated.Value(0))[0];
  const slideUpValue = useState(new Animated.Value(30))[0];
  const logoScale = useState(new Animated.Value(0))[0];
  const inputScale = useState(new Animated.Value(1))[0];
  const buttonPulse = useState(new Animated.Value(1))[0];

  useEffect(() => {
    // Smooth entrance animations
    Animated.parallel([
      Animated.timing(fadeInValue, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideUpValue, {
        toValue: 0,
        duration: 700,
        useNativeDriver: true,
      }),
      Animated.spring(logoScale, {
        toValue: 1,
        tension: 100,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handlePhoneNumberChange = (text: string) => {
    const numericText = text.replace(/[^0-9]/g, '');
    // Flexible length based on selected country - most countries use 10 digits
    const maxLength = selectedCountry.dialCode === '+1' ? 10 : 10; // US has 10, most others 10
    if (numericText.length <= maxLength) {
      setPhoneNumber(numericText);
    }
  };

  const handleSubmit = async () => {
    if (!phoneNumber || phoneNumber.length < 10) {
      onError('Please enter a valid phone number');
      return;
    }

    setIsLoading(true);

    // Premium button press animation
    Animated.sequence([
      Animated.timing(buttonPulse, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(buttonPulse, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();

    try {
      const fullPhoneNumber = selectedCountry.dialCode + phoneNumber;
      console.log('Sending OTP to:', fullPhoneNumber);

      const result = await authService.sendOTP(fullPhoneNumber);

      if (result.confirm) {
        onOTPSent(fullPhoneNumber);
      } else {
        onError(result.error || 'Failed to send OTP');
      }
    } catch (error: any) {
      onError(error.message || 'Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const displayPhoneNumber = () => {
    return phoneNumber;
  };

  const isValidPhone = phoneNumber.length >= 10;
  const { width, height } = Dimensions.get('window');

  const renderCountryPicker = () => {
    if (!showCountryPicker) return null;

    return (
      <View style={styles.countryPickerOverlay}>
        <View style={[styles.countryPickerContainer, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.countryPickerTitle, { color: theme.colors.text }]}>
            Select Country
          </Text>
          <ScrollView style={styles.countryList} showsVerticalScrollIndicator={false}>
            {COUNTRY_CODES.map((country, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.countryOption, index === 0 && styles.firstCountryOption]}
                onPress={() => {
                  setSelectedCountry(country);
                  setShowCountryPicker(false);
                }}
              >
                <Text style={styles.countryFlag}>{country.flag}</Text>
                <View style={styles.countryDetails}>
                  <Text style={[styles.countryName, { color: theme.colors.text }]}>
                    {country.name}
                  </Text>
                  <Text style={[styles.countryDialCode, { color: theme.colors.textSecondary }]}>
                    {country.dialCode}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <TouchableOpacity
            style={[styles.countryPickerClose, { backgroundColor: theme.colors.primary }]}
            onPress={() => setShowCountryPicker(false)}
          >
            <Text style={[styles.countryPickerCloseText, { color: theme.colors.white }]}>
              Close
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <Animated.View
      style={[
        styles.container,
        {
          opacity: fadeInValue,
          transform: [{ translateY: slideUpValue }],
        },
      ]}
    >
      {/* Premium Header with Logo */}
      <View style={styles.headerSection}>
        <Animated.View
          style={[
            styles.logoContainer,
            {
              transform: [{ scale: logoScale }],
            },
          ]}
        >
          <View style={[styles.logoCircle, { backgroundColor: theme.colors.primary }]}>
            <Text style={styles.logoText}>C</Text>
          </View>
        </Animated.View>

        <Text style={[styles.title, { color: theme.colors.text }]}>
          Welcome to Corpease
        </Text>
        <Text style={[styles.subtitle, { color: theme.colors.textSecondary }]}>
          Enter your phone number to continue your journey
        </Text>
      </View>

      {/* Premium Input Section */}
      <Animated.View
        style={[
          styles.inputSection,
          {
            transform: [{ scale: inputScale }],
          },
        ]}
      >
        <Text style={[styles.inputLabel, { color: theme.colors.text }]}>
          Phone Number
        </Text>

        <TouchableOpacity
          style={styles.inputContainer}
          onPress={() => setShowCountryPicker(true)}
          activeOpacity={0.8}
        >
          <View style={styles.countrySelector}>
            <Text style={[styles.countryDialCode, { color: theme.colors.primary, fontSize: 16, fontWeight: '600' }]}>
              {selectedCountry.dialCode}
            </Text>
          </View>

          <View style={styles.inputSeparator} />

          <TextInput
            style={[styles.phoneInput, { color: '#000000' }]}
            value={displayPhoneNumber()}
            onChangeText={handlePhoneNumberChange}
            placeholder="Enter phone number"
            placeholderTextColor={theme.colors.textSecondary}
            keyboardType="phone-pad"
            maxLength={10}
            editable={!loading && !isLoading}
            onFocus={() => {
              setIsFocused(true);
              Animated.spring(inputScale, {
                toValue: 1.02,
                useNativeDriver: true,
              }).start();
            }}
            onBlur={() => {
              setIsFocused(false);
              Animated.spring(inputScale, {
                toValue: 1,
                useNativeDriver: true,
              }).start();
            }}
          />

          {/* Premium validation indicator */}
          <View style={[
            styles.validationIndicator,
            {
              backgroundColor: isValidPhone ? '#4CAF50' : theme.colors.textSecondary,
              shadowColor: isValidPhone ? '#4CAF50' : theme.colors.textSecondary,
              shadowOffset: { width: 0, height: 0 },
              shadowOpacity: 0.5,
              shadowRadius: 4,
              elevation: isValidPhone ? 4 : 0,
            }
          ]} />
        </TouchableOpacity>

        <Text style={[styles.inputHelper, { color: theme.colors.textSecondary }]}>
          We'll send a verification code to this number
        </Text>
      </Animated.View>

      {/* Premium CTA Button */}
      <Animated.View style={{ transform: [{ scale: buttonPulse }] }}>
        <TouchableOpacity
          style={[
            styles.premiumButton,
            {
              backgroundColor: isValidPhone ? theme.colors.primary : theme.colors.border,
              shadowColor: theme.colors.primary,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: isValidPhone ? 0.4 : 0.1,
              shadowRadius: 16,
              elevation: isValidPhone ? 12 : 2,
            },
          ]}
          onPress={handleSubmit}
          disabled={!isValidPhone || loading || isLoading}
          activeOpacity={0.8}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <>
              <Text style={[styles.premiumButtonText, { color: theme.colors.white }]}>
                Continue with SMS
              </Text>
              <Text style={styles.buttonArrow}>→</Text>
            </>
          )}
        </TouchableOpacity>
      </Animated.View>

      {/* Premium Trust Indicators */}
      <View style={styles.trustSection}>
        <View style={styles.trustItem}>
          <View style={[styles.trustIcon, { backgroundColor: '#E8F5E8' }]}>
            <Text style={styles.trustIconText}>🔒</Text>
          </View>
          <Text style={[styles.trustText, { color: theme.colors.textSecondary }]}>
            End-to-end encrypted
          </Text>
        </View>

        <View style={styles.trustItem}>
          <View style={[styles.trustIcon, { backgroundColor: '#FFF3E0' }]}>
            <Text style={styles.trustIconText}>⚡</Text>
          </View>
          <Text style={[styles.trustText, { color: theme.colors.textSecondary }]}>
            Instant verification
          </Text>
        </View>

        <View style={styles.trustItem}>
          <View style={[styles.trustIcon, { backgroundColor: '#E3F2FD' }]}>
            <Text style={styles.trustIconText}>🛡️</Text>
          </View>
          <Text style={[styles.trustText, { color: theme.colors.textSecondary }]}>
            Your data is secure
          </Text>
        </View>
      </View>

      {/* Premium Terms Section */}
      <View style={styles.termsSection}>
        <Text style={[styles.termsText, { color: theme.colors.textSecondary }]}>
          By continuing, you agree to our{' '}
          <Text style={[styles.termsLink, { color: theme.colors.primary }]}>
            Terms of Service
          </Text>
          {' '}and{' '}
          <Text style={[styles.termsLink, { color: theme.colors.primary }]}>
            Privacy Policy
          </Text>
        </Text>
      </View>

      {renderCountryPicker()}
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 20,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 48,
  },
  logoContainer: {
    marginBottom: 24,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 12,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 12,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    opacity: 0.8,
  },
  inputSection: {
    marginBottom: 40,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 16,
    letterSpacing: 0.3,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 16,
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 20,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  countrySelector: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    minWidth: 60,
    justifyContent: 'center',
  },
  countryFlag: {
    fontSize: 24,
    marginRight: 12,
  },
  countryInfo: {
    marginRight: 12,
  },
  countryName: {
    fontSize: 14,
    fontWeight: '600',
  },
  countryDialCode: {
    fontSize: 12,
    marginTop: 2,
  },
  inputSeparator: {
    width: 1,
    height: 32,
    backgroundColor: 'rgba(0,0,0,0.1)',
    marginHorizontal: 16,
  },
  phoneInput: {
    flex: 1,
    fontSize: 16,
    fontWeight: '500',
    paddingHorizontal: 20,
    paddingVertical: 8,
  },
  validationIndicator: {
    width: 4,
    height: 32,
    borderRadius: 2,
  },
  inputHelper: {
    fontSize: 12,
    marginTop: 12,
    opacity: 0.7,
    textAlign: 'center',
  },
  premiumButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 32,
    borderRadius: 16,
    marginBottom: 40,
    minHeight: 56,
  },
  premiumButtonText: {
    fontSize: 16,
    fontWeight: '600',
    marginRight: 12,
  },
  buttonArrow: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  trustSection: {
    marginBottom: 40,
  },
  trustItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  trustIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  trustIconText: {
    fontSize: 18,
  },
  trustText: {
    fontSize: 14,
    flex: 1,
  },
  termsSection: {
    alignItems: 'center',
  },
  termsText: {
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 18,
    opacity: 0.7,
  },
  termsLink: {
    textDecorationLine: 'underline',
  },
  countryPickerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
    zIndex: 1000,
  },
  countryPickerContainer: {
    maxHeight: '80%',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
  },
  countryPickerTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 20,
    textAlign: 'center',
  },
  countryList: {
    maxHeight: '75%',
  },
  countryOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginBottom: 8,
  },
  firstCountryOption: {
    marginTop: 8,
  },
  countryDetails: {
    flex: 1,
    marginLeft: 16,
  },
  countryPickerClose: {
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
    backgroundColor: '#667eea',
  },
  countryPickerCloseText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
  },
});

export default PhoneAuthForm;
