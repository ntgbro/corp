import React, { useState, useEffect } from 'react';
import { TouchableOpacity, Text, StyleSheet, Animated, View, ActivityIndicator } from 'react-native';
import { useTheme } from '../../../config';

export interface ResendOTPButtonProps {
  onResend: () => void;
  cooldownTime?: number; // seconds
  disabled?: boolean;
  style?: any;
}

export const ResendOTPButton: React.FC<ResendOTPButtonProps> = ({
  onResend,
  cooldownTime = 60,
  disabled = false,
  style,
}) => {
  const theme = useTheme();
  const [countdown, setCountdown] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  // Animation values for premium feel
  const scaleValue = useState(new Animated.Value(1))[0];
  const opacityValue = useState(new Animated.Value(1))[0];
  const pulseValue = useState(new Animated.Value(1))[0];

  useEffect(() => {
    let interval: ReturnType<typeof setTimeout>;

    if (countdown > 0) {
      interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [countdown]);

  // Pulsing animation for active state
  useEffect(() => {
    if (countdown === 0 && !disabled && !isLoading) {
      const pulseAnimation = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseValue, {
            toValue: 1.05,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseValue, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      );
      pulseAnimation.start();

      return () => pulseAnimation.stop();
    }
  }, [countdown, disabled, isLoading]);

  const handleResend = async () => {
    if (countdown > 0 || disabled || isLoading) {
      return;
    }

    setIsLoading(true);
    setCountdown(cooldownTime);

    // Premium press animation
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();

    try {
      await onResend();
    } catch (error) {
      console.error('Resend OTP error:', error);
      setCountdown(0); // Reset countdown on error
    } finally {
      setIsLoading(false);
    }
  };

  const isDisabled = countdown > 0 || disabled || isLoading;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0) {
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    return `${secs}s`;
  };

  const getButtonText = () => {
    if (isLoading) return 'Sending verification code...';
    if (countdown > 0) return `Resend in ${formatTime(countdown)}`;
    return 'Resend verification code';
  };

  const getButtonStyle = () => {
    if (isDisabled) {
      return {
        backgroundColor: 'transparent',
        borderColor: theme.colors.textSecondary,
        borderWidth: 1,
      };
    }
    return {
      backgroundColor: 'transparent',
      borderColor: theme.colors.primary,
      borderWidth: 2,
      shadowColor: theme.colors.primary,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.2,
      shadowRadius: 4,
      elevation: 3,
    };
  };

  return (
    <Animated.View
      style={[
        { transform: [{ scale: scaleValue }, { scale: pulseValue }], opacity: opacityValue },
        style,
      ]}
    >
      <TouchableOpacity
        style={[
          styles.container,
          getButtonStyle(),
        ]}
        onPress={handleResend}
        disabled={isDisabled}
        activeOpacity={0.8}
      >
        <Text
          style={[
            styles.text,
            {
              color: isDisabled ? theme.colors.textSecondary : theme.colors.primary,
            },
          ]}
        >
          {getButtonText()}
        </Text>

        {/* Premium loading indicator */}
        {isLoading && (
          <View style={styles.loadingContainer}>
            <ActivityIndicator
              size="small"
              color={theme.colors.primary}
              style={styles.loadingSpinner}
            />
          </View>
        )}

        {/* Premium visual indicator for active state */}
        {countdown === 0 && !isDisabled && !isLoading && (
          <View style={[styles.activeIndicator, { backgroundColor: theme.colors.primary }]} />
        )}
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
    minHeight: 48,
    position: 'relative',
    marginVertical: 8,
  },
  text: {
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  loadingContainer: {
    position: 'absolute',
    right: 12,
  },
  loadingSpinner: {
    marginLeft: 8,
  },
  activeIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    position: 'absolute',
    right: 12,
    top: '50%',
    marginTop: -4,
  },
});

export default ResendOTPButton;
