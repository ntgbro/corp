// Auth feature exports
export { default as PhoneAuthScreen } from './screens/PhoneAuthScreen';
export { default as OTPVerificationScreen } from './screens/OTPVerificationScreen';
export { default as ProfileSetupScreen } from './screens/ProfileSetupScreen';

// Auth components
export { default as PhoneAuthForm } from './components/PhoneAuthForm';
export { default as ResendOTPButton } from './components/ResendOTPButton';

// Auth hooks
export { default as usePhoneAuth } from './hooks/usePhoneAuth';
export { default as useResendCountdown } from './hooks/useResendCountdown';

// Re-export services and utilities
export * from '../../services/firebase/auth/authService';
export * from '../../services/firebase/auth/authHelpers';

// Re-export global hooks for auth-related functionality
export * from '../../hooks';
