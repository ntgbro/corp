import React from 'react';
import { Text, StyleSheet, TextStyle } from 'react-native';
import { useTheme } from '../../config/theme';

export interface TypographyProps {
  children: React.ReactNode;
  variant?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'body1' | 'body2' | 'caption' | 'button';
  color?: 'primary' | 'secondary' | 'text' | 'error' | 'success' | 'warning';
  style?: TextStyle;
}

export const Typography: React.FC<TypographyProps> = ({
  children,
  variant = 'body1',
  color = 'text',
  style,
}) => {
  const theme = useTheme();

  const getVariantStyles = () => {
    const variants = {
      h1: { fontSize: 32, fontWeight: 'bold', lineHeight: 40 },
      h2: { fontSize: 24, fontWeight: 'bold', lineHeight: 32 },
      h3: { fontSize: 20, fontWeight: '600', lineHeight: 28 },
      h4: { fontSize: 18, fontWeight: '600', lineHeight: 24 },
      h5: { fontSize: 16, fontWeight: '600', lineHeight: 22 },
      h6: { fontSize: 14, fontWeight: '600', lineHeight: 20 },
      body1: { fontSize: 16, fontWeight: '400', lineHeight: 24 },
      body2: { fontSize: 14, fontWeight: '400', lineHeight: 20 },
      caption: { fontSize: 12, fontWeight: '400', lineHeight: 16 },
      button: { fontSize: 14, fontWeight: '500', lineHeight: 20 },
    };
    return variants[variant];
  };

  const getColor = () => {
    const colors = {
      primary: theme.colors.primary,
      secondary: theme.colors.textSecondary,
      text: theme.colors.text,
      error: theme.colors.error,
      success: theme.colors.success,
      warning: theme.colors.warning,
    };
    return colors[color];
  };

  const variantStyles = getVariantStyles();

  return (
    <Text
      style={[
        styles.text,
        {
          ...variantStyles,
          color: getColor(),
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
};

const styles = StyleSheet.create({
  text: {
    textAlign: 'left',
  },
});

export default Typography;
