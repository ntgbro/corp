import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ViewStyle,
  Dimensions,
} from 'react-native';
import { useTheme } from '../../config/theme';
import { useCart } from '../../contexts/CartContext';

export interface ProductData {
  id: string;
  name: string;
  price: number;
  image?: string;
  rating?: number;
  reviewCount?: number;
  isAvailable?: boolean;
  category?: string;
  description?: string;
}

export interface ProductCardProps {
  product: ProductData;
  onPress?: () => void;
  style?: ViewStyle;
  showRating?: boolean;
  showCategory?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onPress,
  style,
  showRating = true,
  showCategory = false,
  size = 'medium',
}) => {
  const theme = useTheme();
  const { addToCart } = useCart();
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const Container = onPress ? TouchableOpacity : View;

  const getSizeStyles = () => {
    // Check if width is provided via style prop (from FlatList grid)
    const hasCustomWidth = style?.width !== undefined;

    switch (size) {
      case 'small':
        return {
          width: hasCustomWidth ? style?.width : 140,
          height: 180, // Reduced height for horizontal scrolling
          borderRadius: 8,
        } as const;
      case 'large':
        return {
          width: hasCustomWidth ? style?.width : '100%',
          height: 280,
          borderRadius: 12,
        } as const;
      default: // medium - optimized for horizontal scrolling
        return {
          width: hasCustomWidth ? style?.width : 160, // Perfect for horizontal FlatList
          height: 240, // Increased height to accommodate longer names
          borderRadius: 12,
        } as const;
    }
  };

  const getFontSizes = () => {
    switch (size) {
      case 'small':
        return {
          title: 11,
          price: 13,
          rating: 10,
        };
      case 'large':
        return {
          title: 16,
          price: 18,
          rating: 12,
        };
      default: // medium
        return {
          title: 13,
          price: 15,
          rating: 11,
        };
    }
  };

  const fontSizes = getFontSizes();

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push('★');
    }

    if (hasHalfStar) {
      stars.push('☆');
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push('☆');
    }

    return stars.join('');
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(price);
  };

  const handleAddToCart = async () => {
    if (isAddingToCart || !product.isAvailable) return;

    setIsAddingToCart(true);

    try {
      // Create cart item matching CartContext interface
      const cartItem = {
        id: `${product.id}_${Date.now()}`, // Unique cart item ID
        productId: product.id,
        name: product.name,
        price: product.price,
        image: product.image || '',
        chefId: 'default-chef', // This should come from product data
        chefName: 'Default Chef', // This should come from product data
      };

      addToCart(cartItem);

      // Show brief success feedback
      setTimeout(() => {
        setIsAddingToCart(false);
      }, 500);
    } catch (error) {
      console.error('Error adding to cart:', error);
      setIsAddingToCart(false);
    }
  };

  return (
    <Container
      onPress={onPress}
      style={[
        styles.container,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.border,
          ...getSizeStyles(),
        },
        style,
      ]}
    >
      {/* Product Image */}
      <View style={styles.imageContainer}>
        {product.image ? (
          <Image
            source={{ uri: product.image }}
            style={styles.image}
            resizeMode="cover"
          />
        ) : (
          <View style={[styles.image, styles.placeholderImage]}>
            <Text style={[styles.placeholderText, { color: theme.colors.textSecondary }]}>
              📷
            </Text>
          </View>
        )}

        {/* Availability Badge */}
        {!product.isAvailable && (
          <View style={[styles.badge, styles.unavailableBadge, { backgroundColor: theme.colors.error }]}>
            <Text style={[styles.badgeText, { color: theme.colors.white }]}>
              Out of Stock
            </Text>
          </View>
        )}
      </View>

      {/* Product Info */}
      <View style={styles.infoContainer}>
        {/* Product Name */}
        <Text
          style={[
            styles.title,
            {
              color: theme.colors.text,
              fontSize: fontSizes.title,
            }
          ]}
          numberOfLines={2}
          ellipsizeMode="tail"
        >
          {product.name}
        </Text>

        {/* Price */}
        <Text
          style={[
            styles.price,
            {
              color: theme.colors.primary,
              fontSize: fontSizes.price,
            }
          ]}
        >
          {formatPrice(product.price)}
        </Text>

        {/* Rating */}
        {showRating && product.rating !== undefined && (
          <View style={styles.ratingContainer}>
            <Text style={[styles.stars, { color: '#FFD700' }]}>
              {renderStars(product.rating)}
            </Text>
            {product.reviewCount !== undefined && (
              <Text style={[styles.reviewCount, { color: theme.colors.textSecondary }]}>
                ({product.reviewCount})
              </Text>
            )}
          </View>
        )}

        {/* Add to Cart Button - Always visible */}
        <TouchableOpacity
          style={[
            styles.addToCartButton,
            {
              backgroundColor: product.isAvailable ? theme.colors.primary : theme.colors.border,
              opacity: isAddingToCart ? 0.7 : 1,
            },
          ]}
          onPress={handleAddToCart}
          disabled={isAddingToCart || !product.isAvailable}
        >
          <Text style={[styles.addToCartText, { color: theme.colors.white }]}>
            {isAddingToCart ? 'Adding...' : product.isAvailable ? '+' : 'Out'}
          </Text>
        </TouchableOpacity>
      </View>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    marginHorizontal: 6, // Increased spacing between cards
    marginVertical: 4, // Added vertical spacing
  },
  imageContainer: {
    width: '100%',
    height: 110, // Reduced image height to give more space for text
    backgroundColor: '#f0f0f0',
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  placeholderImage: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e8e8e8',
  },
  placeholderText: {
    fontSize: 24,
    fontWeight: '500',
    color: '#999',
  },
  badge: {
    position: 'absolute',
    top: 6,
    right: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  unavailableBadge: {
    backgroundColor: '#FF3B30',
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#fff',
  },
  infoContainer: {
    flex: 1,
    padding: 8,
    justifyContent: 'space-between',
    paddingBottom: 6,
  },
  title: {
    fontWeight: '600',
    marginBottom: 2, // Reduced margin
    lineHeight: 14, // Tighter line height
    color: '#333',
  },
  price: {
    fontWeight: 'bold',
    marginBottom: 2, // Reduced margin
    color: '#007AFF',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4, // Reduced margin
  },
  stars: {
    fontSize: 12,
    marginRight: 4,
    color: '#FFD700',
  },
  reviewCount: {
    fontSize: 10,
    color: '#666',
  },
  addToCartButton: {
    backgroundColor: '#007AFF',
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 4,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
    alignSelf: 'stretch', // Ensure button takes full width
  },
  addToCartText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#fff',
  },
});

export default ProductCard;
