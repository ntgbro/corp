import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { ProductCard } from './index';
import { ProductData } from '../../services/firebase/firestore/productService';
import { useThemeContext } from '../../contexts/ThemeContext';

const { width } = Dimensions.get('window');
const ITEM_WIDTH = 160;

interface CategorySectionProps {
  title: string;
  products: ProductData[];
  onProductPress: (product: ProductData) => void;
  onSeeAllPress?: (categoryName: string) => void;
  service?: 'fresh' | 'fmcg' | 'supplies';
}

const CategorySection: React.FC<CategorySectionProps> = ({
  title,
  products: initialProducts,
  onProductPress,
  onSeeAllPress,
  service,
}) => {
  const { theme } = useThemeContext();
  const [products, setProducts] = useState<ProductData[]>(initialProducts);
  const [loading, setLoading] = useState(false);

  // Load products when component mounts or service/category changes
  useEffect(() => {
    const loadProducts = async () => {
      if (service && title) {
        try {
          setLoading(true);
          console.log(`Loading products for service: ${service}, category: ${title}`);

          // Import here to avoid circular dependency
          const { getProductsByService } = await import('../../services/firebase/firestore/productService');

          // First get all products to see what categories are available
          const allProducts = await getProductsByService(service, 1000);
          const availableCategories = [...new Set(allProducts.map(p => p.category).filter(Boolean))];
          console.log(`Available categories for ${service}:`, availableCategories);

          // Import the category function
          const { getProductsByServiceAndCategory } = await import('../../services/firebase/firestore/productService');

          // Try different variations of the category name
          const categoryVariations = [
            title, // Exact match
            title.toLowerCase(),
            title.replace(/\s+/g, '-').toLowerCase(),
            title.replace(/\s+/g, ' ').toLowerCase(),
          ];

          let fetchedProducts: any[] = [];

          for (const categoryName of categoryVariations) {
            try {
              console.log(`Trying category name: "${categoryName}"`);
              fetchedProducts = await getProductsByServiceAndCategory(service, categoryName, 6);
              if (fetchedProducts.length > 0) {
                console.log(`✅ Found ${fetchedProducts.length} products for category: "${categoryName}"`);
                break;
              } else {
                console.log(`❌ No products found for category: "${categoryName}"`);
              }
            } catch (error) {
              console.log(`❌ Error for category: "${categoryName}"`, error);
            }
          }

          if (fetchedProducts.length === 0) {
            console.log(`⚠️ No products found for any variation of category: ${title}`);
            // Try to find the closest match
            const closestMatch = availableCategories.find(cat =>
              cat && (cat.toLowerCase().includes(title.toLowerCase()) ||
              title.toLowerCase().includes(cat.toLowerCase()))
            );
            if (closestMatch) {
              console.log(`🔄 Trying closest match: "${closestMatch}"`);
              fetchedProducts = await getProductsByServiceAndCategory(service, closestMatch, 6);
            }
          }

          setProducts(fetchedProducts);
        } catch (error) {
          console.error('Error loading products for category:', title, error);
          setProducts([]);
        } finally {
          setLoading(false);
        }
      }
    };

    loadProducts();
  }, [service, title]);

  const renderProduct = ({ item }: { item: ProductData }) => (
    <ProductCard
      product={item}
      onPress={() => onProductPress(item)}
      style={{
        width: ITEM_WIDTH,
        marginHorizontal: 4,
      }}
      showRating={true}
      showCategory={false}
    />
  );

  if (products.length === 0 && !loading) {
    return null;
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      {/* Category Header with See All Button */}
      <View style={styles.categoryHeader}>
        <Text style={[styles.categoryTitle, { color: theme.colors.text }]}>
          {title}
        </Text>
        {onSeeAllPress && (
          <TouchableOpacity
            style={[styles.seeAllButton, { borderColor: theme.colors.primary }]}
            onPress={() => onSeeAllPress(title)}
          >
            <Text style={[styles.seeAllText, { color: theme.colors.primary }]}>
              See All
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <Text style={[styles.loadingText, { color: theme.colors.textSecondary }]}>
            Loading products...
          </Text>
        </View>
      ) : (
        <FlatList
          data={products.slice(0, 6)} // Show only first 6 products
          renderItem={renderProduct}
          keyExtractor={(item) => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={[styles.productList, { paddingHorizontal: 16 }]}
          snapToInterval={160 + 12}
          decelerationRate="fast"
          ItemSeparatorComponent={() => <View style={{ width: 8 }} />}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  seeAllButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderRadius: 16,
  },
  seeAllText: {
    fontSize: 14,
    fontWeight: '500',
  },
  productList: {
    paddingHorizontal: 12,
  },
  loadingContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 14,
  },
});

export default CategorySection;
