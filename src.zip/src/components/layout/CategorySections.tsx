import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { useTheme } from '../../config/theme';

interface Category {
  id: string;
  name: string;
  icon?: string;
  isActive?: boolean;
}

interface CategorySectionsProps {
  categories: Category[];
  selectedCategory?: string;
  onCategoryPress?: (category: Category) => void;
  style?: ViewStyle;
  variant?: 'horizontal' | 'grid';
  showIcons?: boolean;
}

export const CategorySections: React.FC<CategorySectionsProps> = ({
  categories,
  selectedCategory,
  onCategoryPress,
  style,
  variant = 'horizontal',
  showIcons = false,
}) => {
  const theme = useTheme();

  const renderCategoryItem = (category: Category) => {
    const isSelected = selectedCategory === category.id;

    return (
      <TouchableOpacity
        key={category.id}
        style={[
          styles.categoryItem,
          variant === 'grid' && styles.gridItem,
          {
            backgroundColor: isSelected ? theme.colors.primary : theme.colors.surface,
            borderColor: isSelected ? theme.colors.primary : theme.colors.border,
          },
        ]}
        onPress={() => onCategoryPress?.(category)}
        activeOpacity={0.7}
      >
        {showIcons && category.icon && (
          <Text style={[styles.categoryIcon, { color: isSelected ? theme.colors.white : theme.colors.primary }]}>
            {category.icon}
          </Text>
        )}
        <Text
          style={[
            styles.categoryName,
            {
              color: isSelected ? theme.colors.white : theme.colors.text,
              fontWeight: isSelected ? '600' : '400',
            },
          ]}
          numberOfLines={1}
        >
          {category.name}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, style]}>
      {variant === 'horizontal' ? (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalContainer}
        >
          {categories.map(renderCategoryItem)}
        </ScrollView>
      ) : (
        <View style={styles.gridContainer}>
          {categories.map(renderCategoryItem)}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  horizontalContainer: {
    paddingHorizontal: 16,
    gap: 12,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 12,
  },
  categoryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    minWidth: 80,
    justifyContent: 'center',
  },
  gridItem: {
    flex: 1,
    minWidth: 100,
    aspectRatio: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    padding: 16,
  },
  categoryIcon: {
    fontSize: 16,
    marginRight: 6,
  },
  categoryName: {
    fontSize: 14,
    textAlign: 'center',
  },
});

export default CategorySections;
