import React from 'react';
import {
  View,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../../config/theme';

interface SafeAreaWrapperProps {
  children: React.ReactNode;
  style?: ViewStyle;
  backgroundColor?: string;
  edges?: ('top' | 'bottom' | 'left' | 'right')[];
  variant?: 'default' | 'surface' | 'primary' | 'transparent';
}

export const SafeAreaWrapper: React.FC<SafeAreaWrapperProps> = ({
  children,
  style,
  backgroundColor,
  edges = ['top', 'bottom'],
  variant = 'default',
}) => {
  const theme = useTheme();

  const getBackgroundColor = () => {
    if (backgroundColor) return backgroundColor;

    const variantColors = {
      default: theme.colors.background,
      surface: theme.colors.surface,
      primary: theme.colors.primary,
      transparent: 'transparent',
    };

    return variantColors[variant];
  };

  return (
    <SafeAreaView style={[{ flex: 1, backgroundColor: getBackgroundColor() }, style]} edges={edges}>
      <View style={styles.content}>
        {children}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
});

export default SafeAreaWrapper;
