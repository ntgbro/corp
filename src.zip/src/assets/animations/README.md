// Lottie animation JSON files
// loading.json - Generic loading spinner
// order_complete.json - Order success animation
// empty_cart.json - Empty state animation
