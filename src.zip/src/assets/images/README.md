// Placeholder for logo.png
// Should be 512x512px, transparent background
// Used in splash screen and app headers
