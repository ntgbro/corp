// SVG icons for navigation and UI elements
// home.svg, cart.svg, profile.svg, search.svg, etc.
// Should be 24x24px, single color, optimized
