// Order specific types
export interface OrderDetail {
  id: string;
  orderNumber: string;
  userId: string;
  chefId: string;
  items: OrderItem[];
  status: OrderStatus;
  statusHistory: OrderStatusUpdate[];
  subtotal: number;
  tax: number;
  deliveryFee: number;
  discount: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentTransactionId?: string;
  deliveryAddress: DeliveryAddress;
  deliveryInstructions?: string;
  contactlessDelivery: boolean;
  estimatedDeliveryTime: any;
  actualDeliveryTime?: any;
  chefNotes?: string;
  customerNotes?: string;
  rating?: number;
  review?: string;
  createdAt: any;
  updatedAt: any;
  completedAt?: any;
  cancelledAt?: any;
  cancellationReason?: string;
  refundAmount?: number;
  refundReason?: string;
  deliveryPartner?: DeliveryPartner;
  tracking?: OrderTracking;
  promotions?: AppliedPromotion[];
  chefInfo: {
    id: string;
    name: string;
    phoneNumber: string;
    rating: number;
    location: {
      latitude: number;
      longitude: number;
    };
  };
  customerInfo: {
    id: string;
    name: string;
    phoneNumber: string;
  };
}

export type OrderStatus =
  | 'pending'           // Order placed, awaiting confirmation
  | 'confirmed'         // Chef confirmed the order
  | 'preparing'        // Chef is preparing the order
  | 'ready'            // Order is ready for pickup/delivery
  | 'picked_up'        // Delivery partner picked up the order
  | 'out_for_delivery' // Order is out for delivery
  | 'delivered'        // Order delivered successfully
  | 'cancelled'        // Order cancelled
  | 'refunded';        // Order refunded

export interface OrderStatusUpdate {
  status: OrderStatus;
  timestamp: any;
  updatedBy: string; // userId or 'system'
  notes?: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  name: string;
  description?: string;
  image: string;
  price: number;
  quantity: number;
  unit: string;
  specialInstructions?: string;
  customizations?: OrderItemCustomization[];
  subtotal: number;
  chefId: string;
  chefName: string;
  preparationTime: number;
  status: 'pending' | 'preparing' | 'ready';
}

export interface OrderItemCustomization {
  type: string;
  name: string;
  value: string;
  priceModifier: number;
}

export type PaymentMethod = 'cash' | 'card' | 'upi' | 'net_banking' | 'wallet' | 'cod';

export type PaymentStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'refunded' | 'partially_refunded';

export interface DeliveryAddress {
  id: string;
  type: 'home' | 'work' | 'other';
  label: string;
  street: string;
  city: string;
  state: string;
  pincode: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  instructions?: string;
  contactNumber?: string;
}

export interface DeliveryPartner {
  id: string;
  name: string;
  phoneNumber: string;
  vehicleType: 'bike' | 'car' | 'truck' | 'bicycle';
  rating: number;
  location: {
    latitude: number;
    longitude: number;
  };
}

export interface OrderTracking {
  currentLocation?: {
    latitude: number;
    longitude: number;
  };
  estimatedArrivalTime?: any;
  distanceToDestination?: number;
  deliveryPartner?: DeliveryPartner;
  trackingUrl?: string;
  trackingId?: string;
}

export interface AppliedPromotion {
  id: string;
  code: string;
  type: 'percentage' | 'fixed' | 'free_delivery' | 'buy_one_get_one';
  value: number;
  description: string;
  appliedAmount: number;
  validFrom: any;
  validTo: any;
}

// Order query and filter types
export interface OrderQuery {
  userId?: string;
  chefId?: string;
  status?: OrderStatus[];
  paymentStatus?: PaymentStatus[];
  paymentMethod?: PaymentMethod[];
  dateRange?: {
    start: any;
    end: any;
  };
  priceRange?: {
    min: number;
    max: number;
  };
  sortBy?: OrderSortOption;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export type OrderSortOption =
  | 'created_at'
  | 'updated_at'
  | 'delivery_time'
  | 'total_amount'
  | 'status'
  | 'rating';

export interface OrderStats {
  totalOrders: number;
  totalRevenue: number;
  averageOrderValue: number;
  ordersByStatus: Record<OrderStatus, number>;
  ordersByPaymentMethod: Record<PaymentMethod, number>;
  topSellingItems: {
    productId: string;
    name: string;
    quantity: number;
    revenue: number;
  }[];
  revenueByDay: {
    date: string;
    revenue: number;
    orders: number;
  }[];
  customerRetention: {
    newCustomers: number;
    returningCustomers: number;
    retentionRate: number;
  };
}

// Order form types
export interface CreateOrderForm {
  items: Omit<OrderItem, 'id' | 'subtotal'>[];
  deliveryAddressId: string;
  deliveryInstructions?: string;
  contactlessDelivery: boolean;
  paymentMethod: PaymentMethod;
  promotionCode?: string;
  customerNotes?: string;
}

export interface UpdateOrderForm {
  id: string;
  status?: OrderStatus;
  deliveryInstructions?: string;
  contactlessDelivery?: boolean;
  chefNotes?: string;
  customerNotes?: string;
  rating?: number;
  review?: string;
}

// Order validation types
export interface OrderValidationErrors {
  items?: string;
  deliveryAddress?: string;
  paymentMethod?: string;
  totalAmount?: string;
  [key: string]: string | undefined;
}

// Real-time order updates
export interface OrderUpdate {
  orderId: string;
  type: 'status_change' | 'location_update' | 'message' | 'rating';
  data: any;
  timestamp: any;
}

export interface OrderNotification {
  id: string;
  orderId: string;
  userId: string;
  type: 'status_update' | 'delay' | 'ready' | 'delivered' | 'issue';
  title: string;
  message: string;
  data?: any;
  read: boolean;
  createdAt: any;
}
