// src/types/firestore.ts
// TypeScript interfaces for Firestore database collections based on the schema in corpase explian.md

export interface User {
  userId: string;
  email: string;
  phone: string;
  displayName: string;
  profilePhotoURL: string;
  role: 'customer' | 'restaurant_owner' | 'admin' | 'delivery_partner';
  status: 'active' | 'suspended' | 'pending_verification' | 'deactivated';
  preferences: {
    cuisines: string[];
    foodTypes: string[];
    notifications: {
      orderUpdates: boolean;
      promotions: boolean;
      offers: boolean;
    };
  };
  loyaltyPoints: number;
  totalOrders: number;
  joinedAt: Date;
}

export interface Notification {
  notificationId: string;
  title: string;
  message: string;
  type: 'order' | 'promotion' | 'payment' | 'general';
  relatedOrderId?: string;
  imageURL?: string;
  isRead: boolean;
  createdAt: Date;
  actionURL?: string;
}

export interface Address {
  addressId: string;
  label: 'Home' | 'Work' | 'Other';
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  geoPoint: { latitude: number; longitude: number };
  cityId: string;
  contactName: string;
  contactPhone: string;
  isDefault: boolean;
  isActive: boolean;
}

export interface Cart {
  cartId: string;
  restaurantId?: string;
  warehouseId?: string;
  status: 'active' | 'checked_out' | 'abandoned';
  totalAmount: number;
  itemCount: number;
  addedAt: Date;
  updatedAt: Date;
  deliveryType: 'delivery' | 'pickup';
  appliedCoupon?: {
    couponId: string;
    discountAmount: number;
  };
  serviceId: string;
}

export interface CartItem {
  itemId: string;
  menuItemId?: string;
  productId?: string;
  name: string;
  price: number;
  quantity: number;
  totalPrice: number;
  customizations?: Array<{
    name: string;
    price: number;
  }>;
  notes?: string;
  addedAt: Date;
}

export interface WishlistItem {
  wishlistId: string;
  type: 'restaurant' | 'warehouse' | 'menu_item' | 'product';
  restaurantId?: string;
  warehouseId?: string;
  itemId?: string;
  addedAt: Date;
  serviceId: string;
  price?: number;
}

export interface Session {
  sessionId: string;
  deviceId: string;
  platform: 'ios' | 'android' | 'web';
  fcmToken: string;
  ipAddress: string;
  lastSeenAt: Date;
  isActive: boolean;
  createdAt: Date;
}

export interface CouponUsage {
  usageId: string;
  couponId: string;
  orderId: string;
  discountApplied: number;
  usedAt: Date;
}

export interface Restaurant {
  restaurantId: string;
  name: string;
  ownerId: string;
  logoURL: string;
  bannerURL: string;
  galleryURLs: string[];
  description: string;
  address: {
    line1: string;
    city: string;
    state: string;
    pincode: string;
    geoPoint: { latitude: number; longitude: number };
  };
  cityId: string;
  phone: string;
  email: string;
  cuisines: string[];
  avgRating: number;
  totalRatings: number;
  priceRange: string;
  openHours: {
    monday: { open: string; close: string };
    tuesday: { open: string; close: string };
    wednesday: { open: string; close: string };
    thursday: { open: string; close: string };
    friday: { open: string; close: string };
    saturday: { open: string; close: string };
    sunday: { open: string; close: string };
  };
  deliveryCharges: number;
  freeDeliveryAbove: number;
  minOrderAmount: number;
  maxDeliveryRadius: number;
  avgDeliveryTime: string;
  isActive: boolean;
  isPromoted: boolean;
  isPureVeg: boolean;
  hasOnlinePayment: boolean;
  hasCashOnDelivery: boolean;
  orderCount: number;
  createdAt: Date;
  updatedAt: Date;
  serviceId: string;
}

export interface MenuItem {
  menuItemId: string;
  name: string;
  description: string;
  mainImageURL: string;
  galleryURLs: string[];
  price: number;
  discountedPrice?: number;
  category: string;
  subCategory?: string;
  cuisine: string;
  foodType: string;
  isVeg: boolean;
  isAvailable: boolean;
  prepTime: string;
  spiceLevel: string;
  portionSize: string;
  tags: string[];
  nutritionalInfo?: {
    calories: number;
    protein: string;
    carbs: string;
    fat: string;
    fiber: string;
  };
  allergens: string[];
  ingredients: string[];
  customizationOptions?: Array<{
    name: string;
    options: Array<{ name: string; price: number }>;
    isRequired: boolean;
  }>;
  status: 'active' | 'inactive' | 'out_of_stock';
  orderCount: number;
  rating: number;
  createdAt: Date;
  updatedAt: Date;
  serviceId: string;
}

export interface Inventory {
  inventoryId: string;
  ingredientId: string;
  name: string;
  currentStock: number;
  unit: string;
  reorderLevel: number;
  maxStockLevel: number;
  costPerUnit: number;
  supplierId: string;
  category: string;
  expiryDate: Date;
  batchNumber: string;
  lastRestocked: Date;
  status: 'active' | 'low_stock' | 'out_of_stock';
  totalCost: number;
}

export interface Movement {
  movementId: string;
  type: 'addition' | 'deduction';
  quantity: number;
  unit: string;
  reason: string;
  doneBy: string;
  createdAt: Date;
}

export interface Chef {
  chefId: string;
  name: string;
  age: number;
  gender: string;
  experience: string;
  availability: 'active' | 'break' | 'day_off';
  photoURL: string;
  rating: number;
  contact: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Review {
  reviewId: string;
  userId: string;
  orderId: string;
  rating: number;
  comment: string;
  imageURLs: string[];
  isVerified: boolean;
  helpfulCount: number;
  createdAt: Date;
  restaurantReply?: {
    message: string;
    repliedAt: Date;
  };
}

export interface Order {
  orderId: string;
  userId: string;
  restaurantId?: string;
  warehouseId?: string;
  deliveryPartnerId?: string;
  type: 'restaurant' | 'warehouse';
  deliveryType: 'delivery' | 'pickup';
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'out_for_delivery' | 'delivered' | 'cancelled';
  totalAmount: number;
  discount: number;
  deliveryCharges: number;
  taxes: number;
  finalAmount: number;
  paymentStatus: 'paid' | 'pending' | 'failed' | 'refunded';
  paymentMethod: 'UPI' | 'card' | 'cod' | 'wallet';
  deliveryAddress: {
    addressId: string;
    line1: string;
    line2?: string;
    city: string;
    pincode: string;
    geoPoint: { latitude: number; longitude: number };
    contactName: string;
    contactPhone: string;
    saveForFuture: boolean;
  };
  estimatedDeliveryTime: string;
  actualDeliveryTime?: string;
  instructions?: string;
  appliedCoupons: Array<{
    couponId: string;
    discountAmount: number;
  }>;
  createdAt: Date;
  updatedAt: Date;
  scheduledFor?: Date;
  cancellationReason?: string;
  refundAmount?: number;
}

export interface OrderItem {
  itemId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  type: 'menu_item' | 'product';
  category: string;
  cuisine?: string;
  foodType?: string;
  customizations?: Array<{
    name: string;
    price: number;
  }>;
  links: {
    menuItemId?: string;
    productId?: string;
    restaurantId?: string;
    warehouseId?: string;
  };
  chefId?: string;
  prepTime: string;
  status: 'pending' | 'preparing' | 'ready';
}

export interface StatusHistory {
  statusId: string;
  status: string;
  updatedBy: 'restaurant' | 'delivery_partner' | 'system' | 'user';
  timestamp: Date;
  remarks: string;
  location?: {
    lat: number;
    lng: number;
  };
  estimatedTime?: string;
}

export interface Payment {
  transactionId: string;
  amount: number;
  status: 'success' | 'pending' | 'failed';
  method: string;
  provider: string;
  gateway: string;
  gatewayTransactionId: string;
  timestamp: Date;
  failureReason?: string;
  refundTransactionId?: string;
}

// Additional collections
export interface Promotion {
  promotionId: string;
  title: string;
  description: string;
  bannerImageURL: string;
  type: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount: number;
  maxDiscountAmount?: number;
  targetAudience: {
    userType: string;
    cities: string[];
    restaurants: string[];
    warehouses: string[];
  };
  validFrom: Date;
  validTill: Date;
  usageLimit: {
    totalUsage: number;
    usedCount: number;
    perUserLimit: number;
  };
  isActive: boolean;
  priority: number;
  termsAndConditions: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Coupon {
  couponId: string;
  code: string;
  title: string;
  description: string;
  imageURL?: string;
  type: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount: number;
  maxDiscountAmount?: number;
  usageLimit: {
    totalUsage: number;
    usedCount: number;
    perUserLimit: number;
  };
  applicableFor: {
    userType: string;
    cities: string[];
    restaurants: string[];
    warehouses: string[];
    categories: string[];
    minOrderCount: number;
    dayOfWeek: string[];
  };
  validFrom: Date;
  validTill: Date;
  isActive: boolean;
  isStackable: boolean;
  termsAndConditions: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface City {
  cityId: string;
  name: string;
  state: string;
  country: string;
  coordinates: { latitude: number; longitude: number };
  timezone: string;
  isServiceable: boolean;
  deliveryZones: Array<{
    name: string;
    pincodes: string[];
    deliveryFee: number;
    freeDeliveryAbove: number;
  }>;
  popularAreas: string[];
  currency: string;
  taxRate: number;
  createdAt: Date;
  updatedAt: Date;
  status: 'active';
  isActive: boolean;
}

export interface DeliveryPartner {
  partnerId: string;
  userId: string;
  name: string;
  phone: string;
  email: string;
  profilePhotoURL: string;
  vehicleType: string;
  vehicleNumber: string;
  licenseNumber: string;
  licenseImageURL: string;
  aadharNumber: string;
  aadharImageURL: string;
  bankDetails: {
    accountNumber: string;
    ifscCode: string;
    accountHolderName: string;
  };
  currentLocation: {
    lat: number;
    lng: number;
    lastUpdated: Date;
  };
  status: 'online' | 'offline' | 'busy';
  rating: number;
  totalRatings: number;
  totalDeliveries: number;
  cityId: string;
  serviceAreas: string[];
  isVerified: boolean;
  kycVerified: boolean;
  isAvailable: boolean;
  joinedAt: Date;
  lastActive: Date;
  earnings: {
    totalEarned: number;
    thisMonth: number;
    pendingAmount: number;
  };
}

export interface PaymentRecord {
  paymentId: string;
  orderId: string;
  userId: string;
  amount: number;
  method: string;
  provider: string;
  status: 'success' | 'pending' | 'failed';
  txnscreenshot?: string;
  gatewayTransactionId: string;
  gatewayResponse: {
    code: string;
    message: string;
  };
  timestamp: Date;
  fees: {
    gatewayFee: number;
    platformFee: number;
  };
}
