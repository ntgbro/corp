// Product specific types
export interface ProductDetail {
  id: string;
  name: string;
  description: string;
  shortDescription?: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  discountType?: 'percentage' | 'fixed';
  images: string[];
  thumbnailImage?: string;
  categoryId: string;
  chefId: string;
  serviceType: ServiceType;
  isAvailable: boolean;
  isActive: boolean;
  stock: number;
  stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
  unit: string;
  minOrderQuantity: number;
  maxOrderQuantity?: number;
  rating: number;
  reviewCount: number;
  totalRatings: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
  preparationTime: number; // in minutes
  tags: string[];
  featuredTags: string[];
  nutritionInfo?: NutritionInfo;
  allergens: Allergen[];
  ingredients: string[];
  servingSize: string;
  servingsPerUnit: number;
  spiceLevel: SpiceLevel;
  isVegetarian: boolean;
  isVegan: boolean;
  isGlutenFree: boolean;
  isOrganic: boolean;
  isHalal: boolean;
  isKosher: boolean;
  certifications: string[];
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string[];
  createdAt: any;
  updatedAt: any;
  publishedAt?: any;
  chefInfo: {
    id: string;
    name: string;
    rating: number;
    isVerified: boolean;
    location: {
      latitude: number;
      longitude: number;
    };
  };
  availability: {
    isAvailable: boolean;
    availableFrom?: string;
    availableUntil?: string;
    availableDays: string[];
    blackoutDates?: string[];
  };
  variations?: ProductVariation[];
  relatedProducts?: string[];
  crossSellProducts?: string[];
  upsellProducts?: string[];
}

export type ServiceType = 'Fresh Serve' | 'FMCG' | 'Supplies' | 'Meal Kits' | 'Catering';

export type SpiceLevel = 'none' | 'mild' | 'medium' | 'hot' | 'extra-hot';

export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sugar?: number;
  sodium?: number;
  servingSize: string;
  servingsPerContainer: number;
}

export type Allergen =
  | 'dairy'
  | 'eggs'
  | 'fish'
  | 'crustacean-shellfish'
  | 'tree-nuts'
  | 'peanuts'
  | 'wheat'
  | 'soy'
  | 'sesame'
  | 'sulfites'
  | 'mustard'
  | 'celery'
  | 'molluscan-shellfish'
  | 'gluten'
  | 'lupin'
  | 'other';

export interface ProductVariation {
  id: string;
  name: string;
  type: 'size' | 'flavor' | 'spice_level' | 'custom';
  options: ProductVariationOption[];
  required: boolean;
  multiple: boolean;
}

export interface ProductVariationOption {
  id: string;
  name: string;
  value: string;
  priceModifier: number;
  isAvailable: boolean;
  isDefault: boolean;
}

// Product query and filter types
export interface ProductQuery {
  categoryId?: string;
  chefId?: string;
  serviceType?: ServiceType;
  search?: string;
  priceRange?: {
    min: number;
    max: number;
  };
  rating?: number;
  dietaryRestrictions?: DietaryRestriction[];
  allergens?: Allergen[];
  spiceLevel?: SpiceLevel[];
  isVegetarian?: boolean;
  isVegan?: boolean;
  isOrganic?: boolean;
  tags?: string[];
  location?: {
    latitude: number;
    longitude: number;
    radius: number; // in km
  };
  sortBy?: ProductSortOption;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export type ProductSortOption =
  | 'name'
  | 'price'
  | 'rating'
  | 'distance'
  | 'preparation_time'
  | 'created_at'
  | 'popularity';

export type DietaryRestriction = 'vegetarian' | 'vegan' | 'halal' | 'kosher' | 'gluten-free';

// Product form types
export interface CreateProductForm {
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  categoryId: string;
  serviceType: ServiceType;
  images: string[];
  preparationTime: number;
  unit: string;
  minOrderQuantity: number;
  tags: string[];
  isVegetarian: boolean;
  isVegan: boolean;
  isOrganic: boolean;
  allergens: Allergen[];
  ingredients: string[];
  nutritionInfo?: NutritionInfo;
  spiceLevel: SpiceLevel;
  isAvailable: boolean;
}

export interface UpdateProductForm extends Partial<CreateProductForm> {
  id: string;
}

// Product analytics types
export interface ProductStats {
  id: string;
  totalOrders: number;
  totalRevenue: number;
  averageRating: number;
  totalReviews: number;
  conversionRate: number;
  viewsCount: number;
  cartAddCount: number;
  favoriteCount: number;
  returnRate: number;
  topSellingVariants: string[];
  peakOrderingTimes: {
    hour: number;
    dayOfWeek: number;
    orders: number;
  }[];
}

export interface ProductPerformance {
  productId: string;
  period: 'day' | 'week' | 'month';
  metrics: {
    orders: number;
    revenue: number;
    views: number;
    conversionRate: number;
    averageOrderValue: number;
  };
  trends: {
    ordersChange: number;
    revenueChange: number;
    viewsChange: number;
  };
}
