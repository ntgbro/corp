// Chef specific types
export interface ChefProfile {
  id: string;
  name: string;
  email?: string;
  phoneNumber: string;
  photoURL?: string;
  coverImage?: string;
  rating: number;
  reviewCount: number;
  totalOrders: number;
  totalRevenue: number;
  description: string;
  bio?: string;
  specialties: ChefSpecialty[];
  cuisineTypes: string[];
  location: {
    latitude: number;
    longitude: number;
    address: string;
    city: string;
    state: string;
    pincode: string;
    area: string;
  };
  serviceTypes: ServiceType[];
  serviceAreas: string[];
  isAvailable: boolean;
  isOnline: boolean;
  isVerified: boolean;
  verificationStatus: 'pending' | 'verified' | 'rejected';
  deliveryRadius: number; // in km
  minimumOrder: number;
  averagePreparationTime: number;
  workingHours: WorkingHours;
  menuHighlights: string[];
  certifications: ChefCertification[];
  experience: {
    years: number;
    previousWorkplaces?: string[];
    education?: string[];
    awards?: string[];
  };
  stats: ChefStats;
  availability: ChefAvailability;
  preferences: ChefPreferences;
  bankDetails?: BankDetails;
  createdAt: any;
  updatedAt: any;
  lastActiveAt?: any;
  onboardingCompleted: boolean;
}

export type ChefSpecialty =
  | 'north-indian'
  | 'south-indian'
  | 'gujarati'
  | 'rajasthani'
  | 'bengali'
  | 'punjabi'
  | 'maharashtrian'
  | 'continental'
  | 'italian'
  | 'chinese'
  | 'thai'
  | 'mexican'
  | 'mediterranean'
  | 'fusion'
  | 'healthy'
  | 'desserts'
  | 'beverages'
  | 'street-food'
  | 'traditional'
  | 'modern'
  | 'organic'
  | 'spicy'
  | 'mild';

export type ServiceType = 'Fresh Serve' | 'FMCG' | 'Supplies' | 'Meal Kits' | 'Catering' | 'Bulk Orders';

export interface WorkingHours {
  [key: string]: { // day of week
    open: string; // HH:MM format
    close: string; // HH:MM format
    isOpen: boolean;
    breakStart?: string;
    breakEnd?: string;
  };
}

export interface ChefCertification {
  id: string;
  name: string;
  issuer: string;
  issuedDate: any;
  expiryDate?: any;
  credentialId?: string;
  verificationStatus: 'pending' | 'verified' | 'expired';
  documentUrl?: string;
}

export interface ChefStats {
  totalOrders: number;
  completedOrders: number;
  cancelledOrders: number;
  averageRating: number;
  totalReviews: number;
  totalRevenue: number;
  averageOrderValue: number;
  topSellingItems: {
    productId: string;
    name: string;
    orders: number;
    revenue: number;
  }[];
  monthlyStats: {
    month: string;
    orders: number;
    revenue: number;
  }[];
}

export interface ChefAvailability {
  isAvailable: boolean;
  availableFrom?: string;
  availableUntil?: string;
  availableDays: string[];
  blackoutDates?: string[];
  temporaryClosure?: {
    from: any;
    to: any;
    reason: string;
  };
  maxOrdersPerDay?: number;
  currentOrderLoad: number;
}

export interface ChefPreferences {
  notifications: {
    newOrders: boolean;
    orderUpdates: boolean;
    reviews: boolean;
    promotions: boolean;
    marketing: boolean;
  };
  autoAcceptOrders: boolean;
  maxConcurrentOrders: number;
  preferredDeliveryPartners: string[];
  specialInstructions: string[];
  deliverySettings: {
    handleDelivery: boolean;
    deliveryRadius: number;
    deliveryFee: number;
    minimumDeliveryTime: number;
  };
  paymentSettings: {
    instantPayout: boolean;
    payoutMethod: 'bank' | 'wallet' | 'cash';
    minimumPayoutAmount: number;
  };
}

export interface BankDetails {
  accountHolderName: string;
  accountNumber: string;
  bankName: string;
  branchName: string;
  ifscCode: string;
  accountType: 'savings' | 'current';
  isVerified: boolean;
  verificationStatus: 'pending' | 'verified' | 'rejected';
}

// Chef query and filter types
export interface ChefQuery {
  serviceType?: ServiceType[];
  specialty?: ChefSpecialty[];
  cuisineType?: string[];
  rating?: number;
  priceRange?: {
    min: number;
    max: number;
  };
  location?: {
    latitude: number;
    longitude: number;
    radius: number; // in km
  };
  availability?: {
    isAvailable: boolean;
    deliveryTime?: number;
  };
  sortBy?: ChefSortOption;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export type ChefSortOption =
  | 'name'
  | 'rating'
  | 'distance'
  | 'preparation_time'
  | 'minimum_order'
  | 'created_at'
  | 'total_orders'
  | 'popularity';

export interface ChefMenu {
  id: string;
  chefId: string;
  name: string;
  description: string;
  categories: MenuCategory[];
  items: MenuItem[];
  isActive: boolean;
  availableFrom?: string;
  availableUntil?: string;
  createdAt: any;
  updatedAt: any;
}

export interface MenuCategory {
  id: string;
  name: string;
  description?: string;
  sortOrder: number;
  isActive: boolean;
}

export interface MenuItem {
  id: string;
  menuId: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  image?: string;
  preparationTime: number;
  isVegetarian: boolean;
  isVegan: boolean;
  allergens: string[];
  ingredients: string[];
  spiceLevel: 'mild' | 'medium' | 'hot';
  isAvailable: boolean;
  sortOrder: number;
  customizations?: MenuItemCustomization[];
  createdAt: any;
  updatedAt: any;
}

export interface MenuItemCustomization {
  id: string;
  name: string;
  type: 'single' | 'multiple' | 'quantity';
  required: boolean;
  options: CustomizationOption[];
}

export interface CustomizationOption {
  id: string;
  name: string;
  priceModifier: number;
  isDefault: boolean;
  isAvailable: boolean;
}

// Chef form types
export interface CreateChefForm {
  name: string;
  email?: string;
  phoneNumber: string;
  description: string;
  specialties: ChefSpecialty[];
  serviceTypes: ServiceType[];
  location: {
    address: string;
    city: string;
    state: string;
    pincode: string;
    latitude: number;
    longitude: number;
  };
  workingHours: WorkingHours;
  deliveryRadius: number;
  minimumOrder: number;
  averagePreparationTime: number;
}

export interface UpdateChefForm extends Partial<CreateChefForm> {
  id: string;
}

// Chef validation types
export interface ChefValidationErrors {
  name?: string;
  email?: string;
  phoneNumber?: string;
  description?: string;
  specialties?: string;
  location?: string;
  workingHours?: string;
  deliveryRadius?: string;
  minimumOrder?: string;
  [key: string]: string | undefined;
}
