import initializeApp from '@react-native-firebase/app';
import getFirestore from '@react-native-firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyB0B4tNrApQRWljS7_b2AnBSSXuXli33Y4",
  authDomain: "corpeas-ee450.firebaseapp.com",
  projectId: "corpeas-ee450",
  storageBucket: "corpeas-ee450.firebasestorage.app",
  messagingSenderId: "371942129309",
  appId: "1:371942129309:android:c855b37dce07eb41931e74"
};

// Initialize Firestore
export const db = getFirestore();

export default db;
