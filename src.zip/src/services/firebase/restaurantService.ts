import { db } from './config';
import { Restaurant, MenuItem, Inventory, Movement, Chef, Review } from '../../types/firestore';

// Restaurant Services
export class RestaurantService {
  static async getRestaurant(restaurantId: string): Promise<Restaurant | null> {
    const doc = await db.collection('restaurants').doc(restaurantId).get();
    return doc.exists ? (doc.data() as Restaurant) : null;
  }

  static async getRestaurants(): Promise<Restaurant[]> {
    const snapshot = await db.collection('restaurants').get();
    return snapshot.docs.map(doc => doc.data() as Restaurant);
  }

  static async addMenuItem(restaurantId: string, item: Omit<MenuItem, 'menuItemId'>): Promise<void> {
    const ref = db.collection('restaurants').doc(restaurantId).collection('menu_items').doc();
    await ref.set({ ...item, menuItemId: ref.id });
  }

  static async getMenuItems(restaurantId: string): Promise<MenuItem[]> {
    const snapshot = await db.collection('restaurants').doc(restaurantId).collection('menu_items').get();
    return snapshot.docs.map(doc => doc.data() as MenuItem);
  }

  static async addInventory(restaurantId: string, inventory: Omit<Inventory, 'inventoryId'>): Promise<void> {
    const ref = db.collection('restaurants').doc(restaurantId).collection('inventory').doc();
    await ref.set({ ...inventory, inventoryId: ref.id });
  }

  static async addMovement(restaurantId: string, inventoryId: string, movement: Omit<Movement, 'movementId'>): Promise<void> {
    const ref = db.collection('restaurants').doc(restaurantId).collection('inventory').doc(inventoryId).collection('movements').doc();
    await ref.set({ ...movement, movementId: ref.id });
  }

  static async addChef(restaurantId: string, chef: Omit<Chef, 'chefId'>): Promise<void> {
    const ref = db.collection('restaurants').doc(restaurantId).collection('chefs').doc();
    await ref.set({ ...chef, chefId: ref.id });
  }

  static async addReview(restaurantId: string, review: Omit<Review, 'reviewId'>): Promise<void> {
    const ref = db.collection('restaurants').doc(restaurantId).collection('reviews').doc();
    await ref.set({ ...review, reviewId: ref.id });
  }
}
