import { db } from './config';
import { User, Notification, Address, Cart, CartItem, WishlistItem, Session, CouponUsage } from '../../types/firestore';

// User Services
export class UserService {
  static async getUser(userId: string): Promise<User | null> {
    try {
      const doc = await db.collection('users').doc(userId).get();
      return doc.exists ? (doc.data() as User) : null;
    } catch (error) {
      console.error('Error fetching user:', error);
      return null; // Return null if collection doesn't exist or other error
    }
  }

  static async updateUser(userId: string, data: Partial<User>): Promise<void> {
    await db.collection('users').doc(userId).update(data);
  }

  static async addNotification(userId: string, notification: Omit<Notification, 'notificationId'>): Promise<void> {
    const ref = db.collection('users').doc(userId).collection('notifications').doc();
    await ref.set({ ...notification, notificationId: ref.id });
  }

  static async getNotifications(userId: string): Promise<Notification[]> {
    const snapshot = await db.collection('users').doc(userId).collection('notifications').get();
    return snapshot.docs.map(doc => doc.data() as Notification);
  }

  static async addAddress(userId: string, address: Omit<Address, 'addressId'>): Promise<void> {
    const ref = db.collection('users').doc(userId).collection('addresses').doc();
    await ref.set({ ...address, addressId: ref.id });
  }

  static async getAddresses(userId: string): Promise<Address[]> {
    const snapshot = await db.collection('users').doc(userId).collection('addresses').get();
    return snapshot.docs.map(doc => doc.data() as Address);
  }

  static async updateCart(userId: string, cart: Cart): Promise<void> {
    await db.collection('users').doc(userId).collection('cart').doc(cart.cartId).set(cart);
  }

  static async addCartItem(userId: string, cartId: string, item: Omit<CartItem, 'itemId'>): Promise<void> {
    const ref = db.collection('users').doc(userId).collection('cart').doc(cartId).collection('cart_items').doc();
    await ref.set({ ...item, itemId: ref.id });
  }

  static async addWishlistItem(userId: string, item: Omit<WishlistItem, 'wishlistId'>): Promise<void> {
    const ref = db.collection('users').doc(userId).collection('wishlist').doc();
    await ref.set({ ...item, wishlistId: ref.id });
  }

  static async addSession(userId: string, session: Omit<Session, 'sessionId'>): Promise<void> {
    const ref = db.collection('users').doc(userId).collection('sessions').doc();
    await ref.set({ ...session, sessionId: ref.id });
  }

  static async addCouponUsage(userId: string, usage: Omit<CouponUsage, 'usageId'>): Promise<void> {
    const ref = db.collection('users').doc(userId).collection('coupon_usage').doc();
    await ref.set({ ...usage, usageId: ref.id });
  }
}
