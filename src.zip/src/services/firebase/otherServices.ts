import { db } from './config';
import { Promotion, Coupon, City, DeliveryPartner, PaymentRecord } from '../../types/firestore';

// Promotion Services
export class PromotionService {
  static async getPromotions(): Promise<Promotion[]> {
    const snapshot = await db.collection('promotions').get();
    return snapshot.docs.map(doc => doc.data() as Promotion);
  }
}

// Coupon Services
export class CouponService {
  static async getCoupon(code: string): Promise<Coupon | null> {
    const snapshot = await db.collection('coupons').where('code', '==', code).get();
    return snapshot.empty ? null : (snapshot.docs[0].data() as Coupon);
  }
}

// City Services
export class CityService {
  static async getCities(): Promise<City[]> {
    const snapshot = await db.collection('cities').get();
    return snapshot.docs.map(doc => doc.data() as City);
  }
}

// Delivery Partner Services
export class DeliveryPartnerService {
  static async getPartner(partnerId: string): Promise<DeliveryPartner | null> {
    const doc = await db.collection('delivery_partners').doc(partnerId).get();
    return doc.exists ? (doc.data() as DeliveryPartner) : null;
  }

  static async updateLocation(partnerId: string, location: { lat: number; lng: number }): Promise<void> {
    await db.collection('delivery_partners').doc(partnerId).update({
      'currentLocation.lat': location.lat,
      'currentLocation.lng': location.lng,
      'currentLocation.lastUpdated': new Date(),
    });
  }
}

// Payment Services
export class PaymentService {
  static async getPayment(paymentId: string): Promise<PaymentRecord | null> {
    const doc = await db.collection('payments').doc(paymentId).get();
    return doc.exists ? (doc.data() as PaymentRecord) : null;
  }
}
