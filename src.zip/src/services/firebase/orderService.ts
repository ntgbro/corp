import { db } from './config';
import { Order, OrderItem, StatusHistory, Payment } from '../../types/firestore';

// Order Services
export class OrderService {
  static async getOrder(orderId: string): Promise<Order | null> {
    const doc = await db.collection('orders').doc(orderId).get();
    return doc.exists ? (doc.data() as Order) : null;
  }

  static async getOrdersByUser(userId: string): Promise<Order[]> {
    const snapshot = await db.collection('orders').where('userId', '==', userId).get();
    return snapshot.docs.map(doc => doc.data() as Order);
  }

  static async createOrder(order: Omit<Order, 'orderId'>): Promise<string> {
    const ref = db.collection('orders').doc();
    await ref.set({ ...order, orderId: ref.id });
    return ref.id;
  }

  static async addOrderItem(orderId: string, item: Omit<OrderItem, 'itemId'>): Promise<void> {
    const ref = db.collection('orders').doc(orderId).collection('order_items').doc();
    await ref.set({ ...item, itemId: ref.id });
  }

  static async addStatusHistory(orderId: string, history: Omit<StatusHistory, 'statusId'>): Promise<void> {
    const ref = db.collection('orders').doc(orderId).collection('status_history').doc();
    await ref.set({ ...history, statusId: ref.id });
  }

  static async addPayment(orderId: string, payment: Omit<Payment, 'transactionId'>): Promise<void> {
    const ref = db.collection('orders').doc(orderId).collection('payment').doc();
    await ref.set({ ...payment, transactionId: ref.id });
  }
}
