import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User } from '../types/firestore';
import { UserService } from '../services/firebase/userService';
import auth from '@react-native-firebase/auth';
import { onAuthStateChanged } from '@react-native-firebase/auth';

interface UserProfile extends User {
  isPhoneVerified: boolean;
}

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  error: string | null;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    const setupAuthListener = async () => {
      try {
        if (auth) {
          unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
            try {
              setError(null);
              if (firebaseUser) {
                let userData = await UserService.getUser(firebaseUser.uid);
                if (!userData) {
                  userData = {
                    userId: firebaseUser.uid,
                    phone: firebaseUser.phoneNumber || '',
                    displayName: firebaseUser.displayName || '',
                    email: firebaseUser.email || '',
                    profilePhotoURL: firebaseUser.photoURL || '',
                    role: 'customer',
                    status: 'active',
                    preferences: { cuisines: [], foodTypes: [], notifications: { orderUpdates: true, promotions: true, offers: true } },
                    loyaltyPoints: 0,
                    totalOrders: 0,
                    joinedAt: new Date(),
                  };
                }
                setUser({ ...userData, isPhoneVerified: !!firebaseUser.phoneNumber });
              } else {
                setUser(null);
              }
            } catch (err) {
              console.error('Auth state change error:', err);
              setError('Authentication error');
            } finally {
              setLoading(false);
            }
          });
        } else {
          console.error('Auth not initialized');
          setLoading(false);
        }
      } catch (err) {
        console.error('Setup auth listener error:', err);
        setError('Failed to set up auth listener');
        setLoading(false);
      }
    };

    setupAuthListener();

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const signOut = async (): Promise<void> => {
    await auth.signOut();
    setUser(null);
  };

  const refreshUser = async (): Promise<void> => {
    const currentUser = auth.currentUser;
    if (currentUser) {
      const userData = await UserService.getUser(currentUser.uid);
      if (userData) {
        setUser({ ...userData, isPhoneVerified: !!currentUser.phoneNumber });
      }
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, signOut, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

export default AuthContext;
