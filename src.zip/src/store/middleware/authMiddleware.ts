import { Middleware } from '@reduxjs/toolkit';
import { RootState } from '../index';

// Auth middleware to handle authentication side effects
export const authMiddleware: Middleware = (store) => (next) => (action: unknown) => {
  const result = next(action);
  const typedAction = action as { type: string; payload?: any };

  // Handle user sign out
  if (typedAction.type === 'auth/signOut') {
    // Clear all data when user signs out
    store.dispatch({ type: 'cart/clearCart' } as any);
    store.dispatch({ type: 'orders/clearOrders' } as any);
    store.dispatch({ type: 'products/clearProducts' } as any);
    store.dispatch({ type: 'notifications/clearNotifications' } as any);

    console.log('Auth middleware: Cleared all user data on sign out');
  }

  // Handle user profile updates
  if (typedAction.type === 'auth/updateUser') {
    // Update preferences in other parts of the app
    console.log('Auth middleware: User profile updated', typedAction.payload);
  }

  // Handle successful authentication
  if (typedAction.type === 'auth/setUser' && typedAction.payload) {
    const state = store.getState() as RootState;

    // Update app session info
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    store.dispatch({ type: 'app/setSessionId', payload: sessionId } as any);

    // Track successful login
    console.log('Auth middleware: User logged in successfully', {
      userId: typedAction.payload.id,
      phoneNumber: typedAction.payload.phoneNumber,
      role: typedAction.payload.role,
    });

    // Update preferences in other parts of the app
    console.log('Auth middleware: User profile updated', typedAction.payload);
  }

  // Handle authentication errors
  if (typedAction.type === 'auth/setError') {
    const error = typedAction.payload;

    // Log authentication errors for debugging
    console.error('Auth middleware: Authentication error occurred', error);

    // Could trigger additional error handling here
    // For example, show a user-friendly error message
    // or trigger analytics tracking
  }

  // Handle user preferences updates
  if (typedAction.type === 'auth/updateUserPreferences') {
    const preferences = typedAction.payload;

    // Update notification settings if changed
    if (preferences.notifications !== undefined) {
      store.dispatch({
        type: 'notifications/updateSettings',
        payload: { pushNotifications: preferences.notifications }
      } as any);
    }

    // Update theme if changed
    if (preferences.darkMode !== undefined) {
      const theme = preferences.darkMode ? 'dark' : 'light';
      store.dispatch({ type: 'app/setTheme', payload: theme } as any);
    }

    console.log('Auth middleware: User preferences updated', preferences);
  }

  return result;
};

// Additional auth middleware for token refresh
export const tokenRefreshMiddleware: Middleware = (store) => (next) => (action: unknown) => {
  const result = next(action);
  // Token refresh logic would go here
  return result;
};

// Auth validation middleware
export const authValidationMiddleware: Middleware = (store) => (next) => (action: unknown) => {
  const typedAction = action as { type: string; payload?: any };

  // Validate authentication state before certain actions
  const state = store.getState() as RootState;

  // For example, prevent certain actions if user is not authenticated
  if (typedAction.type.startsWith('orders/') || typedAction.type.startsWith('cart/')) {
    if (!state.auth.isAuthenticated) {
      console.warn('Auth validation: Action requires authentication', typedAction.type);
      // Could dispatch an error or redirect to login
      // store.dispatch({ type: 'auth/setError', payload: 'Authentication required' });
    }
  }

  return next(action);
};

// Auth persistence middleware
export const authPersistenceMiddleware: Middleware = (store) => (next) => (action: unknown) => {
  const result = next(action);

  // Persist authentication state changes
  const typedAction = action as { type: string; payload?: any };

  if (typedAction.type === 'auth/setUser' || typedAction.type === 'auth/signOut') {
    // Trigger save to persistent storage
    // This is handled by the main persistence middleware
    // but we can add additional auth-specific persistence logic here
  }

  return result;
};
