import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { MainStackParamList } from './types';
import ProductScreen from '../features/product/screens/ProductScreen';
import { ProductDetailScreen } from '../features/product/screens/ProductDetailScreen';

const Stack = createStackNavigator<MainStackParamList>();

export const ProductStackNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Products" component={ProductScreen} />
      <Stack.Screen name="SearchResults" component={ProductScreen} />
      <Stack.Screen name="ChefProfile" component={ProductScreen} />
      <Stack.Screen name="ProductDetails" component={ProductDetailScreen} />
    </Stack.Navigator>
  );
};

export default ProductStackNavigator;
