export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
};

export type AuthStackParamList = {
  PhoneAuth: undefined;
  OTPVerification: {
    phoneNumber: string;
    confirm: null; // No longer passing confirmation object
  };
};

export type MainStackParamList = {
  HomeTabs: undefined;
  Products: undefined;
  SearchResults: undefined;
  ChefProfile: { chefId: string };
  ProductDetails: { productId: string };
  ServiceScreen: {
    service: 'fresh' | 'fmcg' | 'supplies';
    title: string;
  };
};

export type MainTabParamList = {
  Home: undefined;
  Product: undefined;
  Cart: undefined;
  Orders: undefined;
  Profile: undefined;
  ProductDetails: { productId: string };
};
