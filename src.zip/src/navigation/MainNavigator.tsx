import React from 'react';
import { MainTabNavigator } from './MainTabNavigator';

const MainNavigator: React.FC = () => {
  return <MainTabNavigator />;
};

export default MainNavigator;
