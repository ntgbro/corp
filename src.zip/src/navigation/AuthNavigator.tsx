import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import PhoneAuthScreen from '../features/auth/screens/PhoneAuthScreen';
import OTPVerificationScreen from '../features/auth/screens/OTPVerificationScreen';

export type AuthStackParamList = {
  PhoneAuth: undefined;
  OTPVerification: { phoneNumber: string; confirm: any };
};

const Stack = createStackNavigator<AuthStackParamList>();

const AuthNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="PhoneAuth"
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="PhoneAuth" component={PhoneAuthScreen} />
      <Stack.Screen name="OTPVerification" component={OTPVerificationScreen} />
    </Stack.Navigator>
  );
};

export default AuthNavigator;
